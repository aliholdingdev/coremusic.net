---
title: "CoreMusic � shared/config Ba�lam"
type: context
folder: "shared/config"
category: layer0-infrastructure
date: 2026-09-21
status: active
version: 1.0.0
---

# shared/config � CLAUDE.md

Route, domain ve OAuth yap�land�rma dosyalar�.

| Dosya | Ama� |
|-------|------|
| outes.php | Ana route tan�mlar� |
| uth-routes.php | Auth-specific route'lar |
| domain.php | Domain haritas� (9 subdomain) |
| oauth-platforms.php | OAuth sa�lay�c� listesi |

**Yasak:** domain.php'yi onays�z de�i�tirmek.