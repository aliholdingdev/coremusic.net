---
title: "CoreMusic � shared/tests/Unit/Config Ba�lam"
type: context
folder: "shared/tests/Unit/Config"
category: testing
date: 2026-09-21
status: active
version: 1.0.0
---

# shared/tests/Unit/Config � CLAUDE.md

ConfigManager, EnvParser unit testleri.

**Hedef:** ?80% coverage.