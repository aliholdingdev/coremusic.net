---
title: "CoreMusic � shared/tests/Unit/Device Ba�lam"
type: context
folder: "shared/tests/Unit/Device"
category: testing
date: 2026-09-21
status: active
version: 1.0.0
---

# shared/tests/Unit/Device � CLAUDE.md

DeviceDetector, DeviceManager unit testleri. 7 cihaz t�r�, 4 tier.

**Hedef:** ?80% coverage.