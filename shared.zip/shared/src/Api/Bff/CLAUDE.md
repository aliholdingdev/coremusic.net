---
title: "CoreMusic - C:\www\coremusic.net\shared\src\Api\Bff Baglam"
type: context
folder: "C:\www\coremusic.net\shared\src\Api\Bff"
category: layer3
date: 2026-09-06
status: active
version: 1.0.0
authority: Single Source of Truth (SSOT)
---

# Bff - CLAUDE.md

**Zorunlu Baglantilar:** . [[../CLAUDE.md]]

## 1. Baglam
Backend-for-Frontend katmani

## 2. Mevcut Durum
| Durum | Deger |
|-------|-------|
| Dosya | 5 |
| Konum | C:\www\coremusic.net\shared\src\Api\Bff |

## 3. Komsu Iliskiler
| Yon | Hedef | Iliski |
|-----|-------|--------|
| Parent | [[../CLAUDE.md]] | Ust baglam |
| Talimatlar | [[../AGENTS.md]] | Ust kurallar |

## 4. Degisiklik Protokolu
1. Degisiklik once ust talimatlarla uyum kontrolu
2. Gerekirse ADR + [[../../.ai/log.md]] audit

---

**Authority:** Bayram Ali / Vault Steward
**Last Updated:** 2026-09-06
