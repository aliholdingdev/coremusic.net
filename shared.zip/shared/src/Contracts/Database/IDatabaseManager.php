<?php declare(strict_types=1);

namespace CoreMusic\Contracts\Database;

interface IDatabaseManager
{
    public function execute(string $sql, array $params = []): array;
    public function write(string $sql, array $params = []): bool;
    public function lastInsertId(): string;
    public function beginTransaction(): bool;
    public function commit(): bool;
    public function rollBack(): bool;
}
