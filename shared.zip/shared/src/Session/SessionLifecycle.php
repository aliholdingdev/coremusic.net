<?php

declare(strict_types=1);

namespace CoreMusic\Session;

use CoreMusic\Session\SessionConfig;

/**
 * SessionLifecycle — session yaşam döngüsü politikalarının tek kaynağı.
 *
 * Idle timeout / lifetime / ID rotation / CSRF-CSP nonce yönetimi.
 * Tüm başlatma ve sıfırlama işlemleri SessionBootstrapper'a delege edilir.
 *
 * (CoreMusic\PageRouter\SessionInitializer'dan taşındı — davranış birebir korunmuştur.)
 */
final class SessionLifecycle
{
    // Sabitler artık SessionConfig'den okunur (SSOT)

    public function startOrExtend(?string $externalNonce = null): array
    {
        $result = [
            'started'          => false,
            'idleTimedOut'     => false,
            'lifetimeTimedOut' => false,
        ];

        SessionBootstrapper::ensureStarted();

        if (session_status() === PHP_SESSION_ACTIVE) {
            if ($this->isSessionExpired()) {
                $result['lifetimeTimedOut'] = true;
                $this->destroy();
                $result['started'] = true;
            } else {
                $this->extendSession();
            }
        }

        if ($this->isIdleTimedOut()) {
            $result['idleTimedOut'] = true;
            $this->destroy();
            $result['started'] = true;
        }

        if (!isset($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token']) || $_SESSION['csrf_token'] === '') {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
        }

        // Dışarıdan nonce gelirse onu kullan, yoksa üret
        $_SESSION['csp_nonce'] = $externalNonce ?? bin2hex(random_bytes(32));

        // Session rotation: 30 dakikada bir session ID yenile
        $lastRotation = $_SESSION['_session_rotated_at'] ?? 0;
        $now = time();
        if ($lastRotation === 0) {
            $_SESSION['_session_rotated_at'] = $now;
        } elseif (($now - $lastRotation) >= SessionConfig::ROTATION_INTERVAL) {
            session_regenerate_id(true);
            $_SESSION['_session_rotated_at'] = $now;
        }

        $now = time();
        $_SESSION['last_activity'] = $now;
        $_SESSION['_session_last_active'] = $now;

        return $result;
    }

    public function destroy(): void
    {
        SessionBootstrapper::restartFresh();
        $this->initSessionKeys();
    }

    public function getCspNonce(): string
    {
        return $_SESSION['csp_nonce'] ?? '';
    }

    public function getSessionData(): array
    {
        return $_SESSION;
    }

    private function initSessionKeys(): void
    {
        $now = time();
        $_SESSION['created_at'] = $now;
        $_SESSION['_session_created_at'] = $now;
        $_SESSION['last_activity'] = $now;
        $_SESSION['_session_last_active'] = $now;
        $_SESSION['_session_rotated_at'] = $now;
    }

    private function isIdleTimedOut(): bool
    {
        $lastActive = $_SESSION['_session_last_active'] ?? $_SESSION['last_activity'] ?? null;
        if ($lastActive === null) {
            return false;
        }
        return (time() - (int)$lastActive) >= SessionConfig::IDLE_TIMEOUT;
    }

    private function isSessionExpired(): bool
    {
        $createdAt = $_SESSION['_session_created_at'] ?? $_SESSION['created_at'] ?? null;
        if ($createdAt === null) {
            return false;
        }
        return (time() - (int)$createdAt) >= SessionConfig::MAX_LIFETIME;
    }

    private function extendSession(): void
    {
        $createdAt = $_SESSION['_session_created_at'] ?? $_SESSION['created_at'] ?? null;
        if ($createdAt === null) {
            $now = time();
            $_SESSION['created_at'] = $now;
            $_SESSION['_session_created_at'] = $now;
            $createdAt = $now;
        }
        if ((time() - (int)$createdAt) >= SessionConfig::MAX_LIFETIME) {
            $this->destroy();
        }
    }
}
