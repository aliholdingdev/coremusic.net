---
title: CoreMusic — Home Page Screen Specification (1024×600, Linux Embedded RPi5)
date: 2026-08-11
updated: 2026-08-11
type: spec
status: active
version: 2.0.0
authority: PNG Visual Analysis (direct inspection — Linux 1024 - Home Page.png)
platform: Linux Embedded / Raspberry Pi 5 / 1024×600px
references:
  - [[00-mockup-index]]
  - [[01-component-inventory]]
  - [[_layout-patterns/02-split-home]]
  - [[decisions/accepted/ADR-001-vanilla-js-itcss]]
  - [[decisions/accepted/ADR-044-dynamic-user-theme-engine]]
---

# CoreMusic — Home Page Screen Specification

## Platform: Linux Embedded / Raspberry Pi 5 / 1024×600px

**Source Image:** `Linux 1024 - Home Page.png`
**Confidence:** High — directly viewed from PNG screenshot.
**Layout Pattern:** Pattern 2: Split Home (42/58 split + grid)

---

## 1. PLATFORM

| Property | Value |
|----------|-------|
| Resolution | 1024×600px |
| Platform | Linux Embedded (Raspberry Pi 5) |
| Orientation | Landscape (fixed) |
| Scale Factor | 1x |
| Device Type | `device_type = 'embedded'` |
| CSS Bundle | `d-embedded.css` (ITCSS 08_Devices) |
| Viewport Height | 600px (minus header 60px + footer 90px = 450px content) |
| Accent Color | `#ff4fd8` (tema motoru ile değiştirilebilir) |
| Background | Tam kaplama fotoğraf + backdrop-filter cam efekti |
| Rota | `/` (ana sayfa) |

---

## 2. ASCII WIREFRAME (Tam Ekran)

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────┐
│ 1024×600 — Linux Embedded RPi5 — home.coremusic.net — Pattern 2: Split Home                    │
├──────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                  │
│ ┌── ZONE A: HEADER (y:0-60, h:60px, fixed) ─────────────────────────────────────────────────┐  │
│ │                                                                                            │  │
│ │  "Core Music"    Ana Sayfa | Keşfet | Albümler | Sanatçılar | Göz At | Geçmiş | ...     │  │
│ │  (Bickham)                       8 nav-link, gap:2-4px, font:Arima 10px                   │  │
│ │                                                                                            │  │
│ │                                                           [Bayram Ali ▾]  [📶✳] [🔋 pill] │  │
│ │                                                           C03 User Pill   C02 Status Widget│  │
│ │                                                                        [⚙ settings][⏻ out]│  │
│ └────────────────────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                                  │
│ ┌── ZONE B-E: İÇERİK BÖLGESİ (y:60-510, h:450px) ─────────────────────────────────────────┐  │
│ │                                                                                            │  │
│ │  ┌── ZONE B: NOW PLAYING CARD ──────────┐  ┌── ZONE C: WIDGET AREA ──────────────────┐  │  │
│ │  │ (sol ~420px, %42)                     │  │ (sağ ~540px, %58)                        │  │  │
│ │  │                                       │  │                                            │  │  │
│ │  │ ┌────────┐ Göksel - Sevil Neşelen    │  │  ┌─ Bluetooth Panel ─────────────────┐   │  │  │
│ │  │ │100×100 │ Hayat Rüya Gibi           │  │  │ 🎵 Hoparlörler                     │   │  │  │
│ │  │ │Album   │ Göksel                    │  │  │    Core Music - Hoparlör            │   │  │  │
│ │  │ │Art     │                           │  │  │    (glass panel)                    │   │  │  │
│ │  │ └────────┘ 00:05:00 ══════ 00:05:00  │  │  └────────────────────────────────────┘   │  │  │
│ │  │              (seek bar, pembe)        │  │                                            │  │  │
│ │  │                                       │  │  ┌─ Hava Durumu Panel ────────────────┐   │  │  │
│ │  └───────────────────────────────────────┘  │  │ ☁ Hava Durumu Görseli              │   │  │  │
│ │                                              │  │    İzmir, TR                        │   │  │  │
│ │                                              │  └────────────────────────────────────┘   │  │  │
│ │                                              │                                            │  │  │
│ │                                              │  ┌─ Takvim Panel ─────────────────────┐   │  │  │
│ │                                              │  │ 📅 07:00                            │   │  │  │
│ │                                              │  │    5 Ağustos 2026                   │   │  │  │
│ │                                              │  │    [≡ calendar icon]                │   │  │  │
│ │                                              │  └────────────────────────────────────┘   │  │  │
│ │                                              │                                            │  │  │
│ │                                              │  ┌─ Klasörlerim Panel ────────────────┐   │  │  │
│ │                                              │  │ 📂 Klasörlerim                      │   │  │  │
│ │                                              │  │    [▶][YT][♥][♫][♥] icon grid      │   │  │  │
│ │                                              │  └────────────────────────────────────┘   │  │  │
│ │                                              └────────────────────────────────────────────┘  │  │
│ │                                                                                            │  │
│ │  ┌── ZONE D: EN SON DİNLENEN ŞARKILAR ──────────────────────────────────────────────┐    │  │
│ │  │ "En Son Dinlenen Şarkılar"                                                         │    │  │
│ │  │ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐                                              │    │  │
│ │  │ │card 1│ │card 2│ │card 3│ │card 4│  ← C09 Media Card, ~140×180px                │    │  │
│ │  │ │thumb │ │thumb │ │thumb │ │thumb │    4 kart yan yana, 1 satır                   │    │  │
│ │  │ │title │ │title │ │title │ │title │    Grid: 4 sütun                               │    │  │
│ │  │ │00:05 │ │00:05 │ │00:05 │ │00:05 │                                               │    │  │
│ │  │ └──────┘ └──────┘ └──────┘ └──────┘                                               │    │  │
│ │  └────────────────────────────────────────────────────────────────────────────────────┘    │  │
│ │                                                                                            │  │
│ │  ┌── ZONE E: OYNATMA LİSTELERİ ─────────────────────────────────────────────────────┐    │  │
│ │  │ "Son Oluşturulan & Sistem Tarafından Oluşturulan Oynatma Listeleri"                │    │  │
│ │  │ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐ ┌──────┐                                     │    │  │
│ │  │ │card 1│ │card 2│ │card 3│ │card 4│ │card 5│  ← C09 Media Card                    │    │  │
│ │  │ │thumb │ │thumb │ │thumb │ │thumb │ │thumb │    5 kart yan yana                    │    │  │
│ │  │ └──────┘ └──────┘ └──────┘ └──────┘ └──────┘                                     │    │  │
│ │  │ ☐ "Oynatma listesini göster" checkbox                                              │    │  │
│ │  └────────────────────────────────────────────────────────────────────────────────────┘    │  │
│ │                                                                                            │  │
│ │  ┌── ZONE F: SIRADAKİ ŞARKILAR ─────────────────────────────────────────────────────┐    │  │
│ │  │ "Sıradaki Şarkılar"                          ┌─ Mini Card ────────────────────┐  │    │  │
│ │  │                                                │ [thumb] Göksel                │  │    │  │
│ │  │                                                │ Sevil Neşelen                 │  │    │  │
│ │  │                                                │ Hayat Rüya Gibi               │  │    │  │
│ │  │                                                └──────────────────────────────┘  │    │  │
│ │  └────────────────────────────────────────────────────────────────────────────────────┘    │  │
│ └────────────────────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                                  │
│ ┌── ZONE G: FOOTER / PLAYER (y:510-600, h:90px, fixed) ────────────────────────────────────┐  │
│ │ [pembe ilerleme çubuğu, y=0, full-width, h:~3px]                                          │  │
│ │                                                                                            │  │
│ │ ┌────────┐ ♪ Şarkı Adı : Göksel - Sevil Neşelen                                          │  │
│ │ │120×120 │ ● Albümüm  : Hayat Rüya Gibi                                                  │  │
│ │ │Album   │ 🎤 Sanatçı  : Göksel                                                           │  │
│ │ │Art     │                                                                                │  │
│ │ └────────┘    [⏮]  [▶]  [⏹]  [⏭]          Süre: 09:00:00 / 00:05:00                    │  │
│ │               ○ ○  ● ○  ○ ○  ○ ○            Bit rate : 320 kbps                           │  │
│ │               (33px çap daireler)               [🔊 ═══▲═══ ] % 100                       │  │
│ └────────────────────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                                  │
│ ARKA PLAN: Tam kaplama fotoğraf (pembe tonları, sunset, fantasy)                                │
│ GLASS: backdrop-filter: blur(Xpx) — cam efekti, yarı saydam paneller                           │
│ ACCENT: #ff4fd8 — ADR-044 tema motoru ile değiştirilebilir                                    │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. ZONE DETAYLARI

### Zone A: Header (Ortak — Tüm Ekranlar)

| Özellik | Değer | Token |
|---------|-------|-------|
| Yükseklik | 60px | `--header-h: 60px` |
| Pozisyon | `position: fixed; top: 0` | — |
| Genişlik | 100vw | — |
| Z-index | 100 | — |
| Background | `rgba(0,0,0,0.3)` + `backdrop-filter: blur(10px)` | `--glass-bg` |
| Border-bottom | 1px solid `rgba(255,255,255,0.1)` | `--border-subtle` |

**Bileşenler:** C01 (nav-link ×8), C02 (status widget), C03 (user pill)
**Detay:** [[_layout-patterns/01-header-footer]] veya backup `header.md` (1307 satır)

---

### Zone B: Now Playing Card

| Özellik | Değer | Token |
|---------|-------|-------|
| Genişlik | ~420px (%42) | — |
| Yükseklik | ~120px | — |
| Padding | 12px | `--space-3` |
| Background | `rgba(255,255,255,0.08)` | `--glass-bg-subtle` |
| Border-radius | 12px | `--radius-lg` |
| Glass | `backdrop-filter: blur(8px)` | `--blur-sm` |

**İçerik:**
- Album Art: 100×100px, border-radius: 8px
- Başlık: Şarkı adı (14px, 600)
- Alt başlık: Albüm adı (12px, 400, muted)
- Sanatçı: (12px, 400)
- Seek bar: Full-width, 3px yükseklik, pembe accent
- Süre: Sol 00:05:00, Sağ 00:05:00 (10px, 400)

**Bileşenler:** C09 (mini card), seek bar (footer player'dan mirror)

---

### Zone C: Widget Area

| Özellik | Değer |
|---------|-------|
| Genişlik | ~540px (%58) |
| Yükseklik | ~280px (Zone B ile aynı satır) |
| Layout | Grid (2×2 veya serbest) |
| Widget'lar | Bluetooth, Hava Durumu, Takvim, Klasörlerim |

**Widget'lar:**
| Widget | Boyut | İçerik | Glass |
|--------|-------|--------|-------|
| Bluetooth | ~250×80px | 🎵 Hoparlörler, Core Music - Hoparlör | ✅ |
| Hava Durumu | ~250×80px | ☁ Görsel, İzmir, TR | ✅ |
| Takvim | ~250×80px | 📅 07:00, 5 Ağustos 2026, [≡] | ✅ |
| Klasörlerim | ~250×80px | 📂 Klasörlerim, [▶][YT][♥][♫][♥] | ✅ |

**Her widget:**
- Background: `rgba(255,255,255,0.08)`
- Border-radius: 12px
- Glass: `backdrop-filter: blur(8px)`
- Padding: 12px

---

### Zone D: En Son Dinlenen Şarkılar

| Özellik | Değer |
|---------|-------|
| Başlık | "En Son Dinlenen Şarkılar" (14px, 600) |
| Grid | 4 sütun × 1-2 satır |
| Kart boyutu | ~140×180px (C09 Media Card) |
| Gap | 8px |
| Padding | 12px |

**Her kart:** thumb (140×140) + title + artist + süre
**Toplam kart sayısı:** ~4-8 (dinamik)

---

### Zone E: Oynatma Listeleri

| Özellik | Değer |
|---------|-------|
| Başlık | "Son Oluşturulan & Sistem Tarafından Oluşturulan Oynatma Listeleri" |
| Grid | 5 sütun × 1 satır |
| Kart boyutu | ~140×180px (C09 Media Card) |
| Gap | 8px |
| Checkbox | "Oynatma listesini göster" (altta) |

**Her kart:** thumb (140×140) + başlık
**Toplam kart sayısı:** 5 (sabit)

---

### Zone F: Sıradaki Şarkılar

| Özellik | Değer |
|---------|-------|
| Başlık | "Sıradaki Şarkılar" (14px, 600) |
| Sağ taraf | Mini Card (sabit, ~200×80px) |
| Mini Card | thumb + şarkı adı + albüm + sanatçı |

**Mini Card:**
- Thumb: ~50×50px
- Başlık: 12px, 600
- Alt metin: 10px, 400, muted
- Background: `rgba(255,255,255,0.08)`
- Border-radius: 8px

---

### Zone G: Footer / Player (Ortak)

| Özellik | Değer | Token |
|---------|-------|-------|
| Yükseklik | 90px | `--footer-h: 90px` (CSS'te 104px yazıyor — çelişki) |
| Pozisyon | `position: fixed; bottom: 0` | — |
| Genişlik | 100vw | — |
| Z-index | 100 | — |
| Background | `rgba(0,0,0,0.5)` + `backdrop-filter: blur(10px)` | `--glass-bg` |
| Border-top | İlerleme çubuğu (3px, pembe) | — |

**Bileşenler:**
- Album Art: 120×120px
- Metadata: Şarkı adı, albüm, sanatçı (sol taraf)
- Transport: ⏮ ▶ ⏹ ⏭ (ortada, 33px çap daireler)
- Seek: Süre + ilerleme çubuğu
- Volume: 🔊 slider + %100
- Bit rate: 320 kbps

**Detay:** [[_layout-patterns/01-header-footer]] veya backup `footer.md` (1213 satır)

---

## 4. BİLEŞEN KULLANIM MATRİSİ

| Bileşen | ID | Sayı | Konum |
|---------|-----|------|-------|
| Nav Link | C01 | 8 | Header (Zone A) |
| Status Widget | C02 | 1 | Header (Zone A) |
| User Pill | C03 | 1 | Header (Zone A) |
| Media Card | C09 | ~14 | Zone D, E |
| Mini Card | — | 1 | Zone F |
| Now Playing Card | — | 1 | Zone B |
| Widget Panel | — | 4 | Zone C |
| Footer Player | — | 1 | Zone G |
| Checkbox | — | 1 | Zone E (alt) |

---

## 5. LAYOUT HESAPLAMALARI

### 5.1 — Dikey

```
Toplam yükseklik: 600px
  Header:          60px  (y: 0-60)
  İçerik:         450px  (y: 60-510)
  Footer:          90px  (y: 510-600)
  Toplam:         600px  ✅
```

### 5.2 — Yatay (İçerik)

```
Toplam genişlik: 1024px
  Sol margin:      16px
  İçerik:         992px (1024 - 2×16)
  Sağ margin:      16px

Zone B (Now Playing): ~420px (%42)
Zone C (Widgets):     ~540px (%58)
Gap:                  ~32px
Toplam: 420 + 32 + 540 = 992px ✅
```

### 5.3 — İçerik Paneli

```
İçerik paneli:
  Üst padding:    11px (y: 60+11=71)
  Alt padding:    15px (y: 510-15=495)
  Yükseklik:      424px (495-71)
  İçerik:         y: 71-495
```

---

## 6. CSS HİYERARŞİSİ

```
d-embedded.css (device-specific)
  ├── 01_Abstracts/a-theme-config.css
  ├── 01_Abstracts/a-layout-tokens.css
  │     └── --header-h: 60px
  │     └── --footer-h: 90px  ← MOCKUP ÖLÇÜMÜ (CSS'te 104px yazıyor)
  │     └── --content-padding-top: 11px
  │     └── --content-padding-bottom: 15px
  ├── 03_Layout/_header.css
  ├── 03_Layout/_footer.css
  ├── 05_Pages/_home.css
  │     └── .home-layout (sidebar YOK)
  │     └── .now-playing-card
  │     └── .widget-area
  │     └── .content-grid
  │     └── .media-card-grid
  └── Device-specific overrides
```

---

## 7. TEMATİK NOTLAR

| Not | Açıklama |
|-----|----------|
| **Tema Değişimi** | Accent rengi `#ff4fd8` (female) → `#4f9fff` (male) → `#a0a0b0` (neutral) |
| **Arka Plan** | Tema rengine göre değişebilir (res-pink/, res-blue/, res-default/) |
| **Glass Efekti** | Tüm paneller `backdrop-filter: blur(Xpx)` kullanır |
| **Touch-First** | Hover yok, focus-visible kullan |
| **Sidebar YOK** | Ana sayfada sidebar yok, sadece Göz At sayfasında var |

---

## 8. RİSKLER VE NOTLAR

| # | Risk | Seviye | Mitigasyon |
|---|------|--------|------------|
| 1 | Footer yüksekliği çelişkisi (90 vs 104px) | HIGH | Mockup 90px esas, token güncellenir |
| 2 | Widget alanının responsive davranışı | MEDIUM | 1024px için sabit grid |
| 3 | Glass blur performansı (RPi5) | LOW | Test gerekli |
| 4 | Font loading gecikmesi (Arima + Bickham) | LOW | FOUT stratejisi |
| 5 | Seek bar hassasiyeti (dokunmatik) | MEDIUM | Min hit area 48px |

---

## 9. İLGİLİ DOSYALAR

| Dosya | Amaç |
|-------|------|
| [[00-mockup-index]] | PNG master kataloğu |
| [[01-component-inventory]] | C01-C16 detayları |
| [[_layout-patterns/02-split-home]] | Split Home layout pattern |
| [[_layout-patterns/01-header-footer]] | Header/Footer ortak spec |
| [[B-home/welcome-popup]] | Hoş geldin modalı |
| [[C-music/albums]] | Albümler sayfası |
| [[ADR-044-dynamic-user-theme-engine]] | Tema motoru |

---

## 10. Quality Report

| Metrik | Değer |
|--------|-------|
| Version | 2.0.0 |
| Platform | Linux Embedded RPi5 1024×600 |
| Layout Pattern | 2: Split Home (42/58 + grid) |
| Zones | 7 (A: Header, B: Now Playing, C: Widgets, D: En Son, E: Listeler, F: Sıradaki, G: Footer) |
| Components Used | 6 (C01, C02, C03, C09, Now Playing, Footer Player) |
| Total Cards | ~14 (C09 Media Card) |
| Widgets | 4 (Bluetooth, Hava, Takvim, Klasörler) |
| Touch Target Issues | 1 (C01 nav-link) |
| ADR Uyumlu | ✅ ADR-001, ADR-044 |
| Zero Hallucination | ✅ Tüm ölçümler PNG piksel ölçümü |

---

*Home Page Screen Spec v2.0.0 — CoreMusic UI Design System*
*Authority: Bayram Ali / Vault Steward*
*Last Updated: 2026-08-11*
*Mode: Red Team · Human Mode · Truth Mode*
