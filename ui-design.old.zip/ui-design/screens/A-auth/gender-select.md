---
title: CoreMusic — Select Gender Screen Specification (1024×600, Linux Embedded RPi5)
date: 2026-08-11
updated: 2026-08-11
type: spec
status: active
version: 2.0.0
authority: PNG Visual Analysis (direct inspection — Linux 1024 - Select Gender.png)
platform: Linux Embedded / Raspberry Pi 5 / 1024×600px
references:
  - [[00-mockup-index]]
  - [[01-component-inventory]]
  - [[_layout-patterns/05-auth-screen]]
---

# CoreMusic — Select Gender Screen Specification

## Platform: Linux Embedded / Raspberry Pi 5 / 1024×600px

**Source Image:** `Linux 1024 - Select Gender.png` + `Linux 1024 - Select Gender - selected.png`
**Confidence:** High — directly viewed from PNG screenshots.
**Layout Pattern:** Pattern 5: Auth Screen (78/22 split)
**Rota:** Auth flow'un ilk adımı

---

## 1. ASCII WIREFRAME

```
┌──────────────────────────────────────────────────────────────────────────────────────────────────┐
│ 1024×600 — Pattern 5: Auth Screen (78/22) — Header/Footer YOK                                  │
├──────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                  │
│  ┌── SOL ALAN (~78%, ~800px) ────────────────────┐  ┌── SAĞ PANEL (~22%, ~224px) ──────────┐  │
│  │                                                 │  │                                       │  │
│  │  [CoreMusic Logo — sol üst]                     │  │  [女神 ikonu — beyaz çizim, üst]     │  │
│  │  Seni Tanıyalım                                 │  │                                       │  │
│  │  Deneyimini sana özel hale getirmek             │  │  Seni Tanıyalım                       │  │
│  │  için bir seçim yapman yeterli.                 │  │  Müzik deneyimini sana özel            │  │
│  │                                                 │  │  getirelim                             │  │
│  │  [Tam kaplama arka plan fotoğrafı]              │  │                                       │  │
│  │  (pembe gradient, fantasy, sunset)              │  │  ┌───────────────────────────┐        │  │
│  │                                                 │  │  │ 👩 Kız                     │        │  │
│  │  Arka plan: pembe tonları, sunset,              │  │  │   Temizlik, saf duygular  │        │  │
│  │  fields, fantasy, girls, wedding                │  │  │   Pembemsi tonlar         │        │  │
│  │                                                 │  │  └───────────────────────────┘        │  │
│  │  Sol üst: "CoreMusic" logosu +                 │  │                                       │  │
│  │  "Seni Tanıyalım" başlığı                      │  │  ┌───────────────────────────┐        │  │
│  │  + açıklama metni                              │  │  │ 👨 Erkek                   │        │  │
│  │                                                 │  │  │   Güçlü, klasik tonlar    │        │  │
│  │                                                 │  │  │   Mavimsi tonlar          │        │  │
│  │                                                 │  │  └───────────────────────────┘        │  │
│  │                                                 │  │                                       │  │
│  │                                                 │  │  ┌───────────────────────────┐        │  │
│  │                                                 │  │  │ 🤷 Cinsiyetimi belirtmek  │        │  │
│  │                                                 │  │  │   istemiyorum              │        │  │
│  │                                                 │  │  │   Nötr tonlar              │        │  │
│  │                                                 │  │  └───────────────────────────┘        │  │
│  │                                                 │  │                                       │  │
│  │                                                 │  │  [Devam Et] (C04, pembe)              │  │
│  │                                                 │  │                                       │  │
│  │                                                 │  │  "Hayatın ritmini sende gizli,         │  │
│  │                                                 │  │   müziğinle parti!"                    │  │
│  │                                                 │  │   (Bickham Script Two, italik)         │  │
│  │                                                 │  │                                       │  │
│  │                                                 │  │  Devam ederek ·Gizlilik Politikamı·    │  │
│  │                                                 │  │  kabul etmiş olursunuz.                │  │
│  │                                                 │  │  (9px, muted)                          │  │
│  └─────────────────────────────────────────────────┘  └───────────────────────────────────────┘   │
│                                                                                                  │
│ Auth akışı: Select Gender (1) → Login (2) → Register (3)                                      │
│ Gender seçimi: Tema rengini değiştirir (female→pink, male→blue, neutral→default)              │
└──────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. SAĞ PANEL DETAYLARI

### 2.1 — Gender Butonları (C07)

| Buton | İkon | Başlık | Alt Metin | Seçildiğinde |
|-------|------|--------|-----------|-------------|
| Kız | 👩 | Kız | Temizlik, saf duygular · Pembemsi renk tonları | Pembe vurgu |
| Erkek | 👨 | Erkek | Güçlü, klasik tonlar · Mavimsi renk tonları | Mavi vurgu |
| Diğer | 🤷 | Cinsiyetimi belirtmek istemiyorum | Nötr renk tonları | Nötr vurgu |

**Her buton:**
- Boyut: ~200×80px (tam genişlik, padding ile)
- Border-radius: 12px
- Border: 1px solid `rgba(255,255,255,0.15)` (default)
- Border: 2px solid `var(--theme-primary)` (selected)
- Background: `rgba(255,255,255,0.05)` (default)
- Background: `rgba(255,79,216,0.2)` (selected, female)
- Gap: 8px

### 2.2 — "Devam Et" Butonu (C04)

| Özellik | Değer |
|---------|-------|
| Genişlik | Tam genişlik (~200px) |
| Yükseklik | 56px |
| Background | `var(--theme-primary)` |
| Text | "Devam Et" |
| Durum | Başlangıçta devre dışı (gri), seçim yapıldığında aktif (pembe) |

### 2.3 — Alt Metin

| Özellik | Değer |
|---------|-------|
| Metin | "Hayatın ritmini sende gizli, müziğinle parti!" |
| Font | Bickham Script Two, italik |
| Boyut | ~14px |
| Renk | `var(--theme-primary)` (pembe) |
| Hizalama | Ortada |

### 2.4 — Gizlilik Politikası

| Özellik | Değer |
|---------|-------|
| Metin | "Devam ederek ·Gizlilik Politikamı· kabul etmiş olursunuz." |
| Font | Arima, 9px |
| Renk | `rgba(255,255,255,0.4)` |
| Link | "Gizlilik Politikamı" — underline, tıklanabilir |

---

## 3. DAVRANIŞ

```
Sayfa yüklenir
  → 3 buton göster (hiçbiri seçili değil)
  → "Devam Et" butonu devre dışı (gri)

Kullanıcı bir butona tıklar
  → Seçili buton pembe vurgu alır
  → Diğer butonlar default'a döner
  → "Devam Et" butonu aktif olur (pembe)

Kullanıcı "Devam Et"'e tıklar
  → Seçim kaydedilir (cookie: theme_gender=female|male|neutral)
  → Tema rengi değişir (CSS custom properties)
  → Login sayfasına yönlendirme
```

---

## 4. WCAG DURUMU

| Kriter | Durum |
|--------|-------|
| Touch target (buton) | ✅ ~200×80px |
| Touch target (devam et) | ✅ 56px |
| Focus indicator | ✅ |
| Keyboard nav | ✅ (Tab ile seçim, Enter ile devam) |
| ARIA | ⚠️ `role="radiogroup"` ekle |
| Renk kontrastı | ✅ |
| Screen reader | ⚠️ `aria-label` ekle |

---

*Select Gender Screen Spec v2.0.0 — CoreMusic UI Design System*
*Last Updated: 2026-08-11*
