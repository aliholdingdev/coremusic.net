---
title: "Layout Pattern — Standard 60/40 Split"
category: layout-pattern
version: "1.0.0"
date: "2026-08-11"
viewport: "1024×600"
---

# Layout Pattern: Standard 60/40 Split

## Kullanım Alanları

- Albums (`/albums`)
- Artists (`/artists`)
- Playlist (`/playlist/:id`)
- Album Detail (`/album/:id`)

## Yapı

```
┌─────────────────────────────────────────────────────────┐
│  HEADER (h=56)                                          │
├──────────────────────────┬──────────────────────────────┤
│                          │                              │
│   LEFT (60% = 614px)    │   RIGHT (40% = 394px)       │
│                          │                              │
│   Card Grid / Track List │   Detail Panel              │
│                          │                              │
│   16px gap ──────────────│                              │
│                          │                              │
├──────────────────────────┴──────────────────────────────┤
│  FOOTER PLAYER (h=64)                                   │
└─────────────────────────────────────────────────────────┘
```

## Kurallar

| Parametre | Değer |
|-----------|-------|
| Sol alan | 60% = 614px |
| Sağ alan | 40% = 394px |
| Gap | 16px |
| Header | h=56, fixed |
| Footer Player | h=64, fixed |
| Sidebar | ❌ Yok |

## Kullanım

Sol tarafta ana içerik (kart ızgarası veya parça listesi), sağ tarafta detay paneli bulunur. Gap iki alan arasında 16px'dir. Sidebar kullanılmaz.

## Bileşen Eşlemesi

| Sol Alan (60%) | Sağ Alan (40%) |
|----------------|----------------|
| C09 Card Grid | C10 Detail Panel |
| C13 Track List | C11 Tabs |
| C12 Stars | C04/C05 Buttons |
