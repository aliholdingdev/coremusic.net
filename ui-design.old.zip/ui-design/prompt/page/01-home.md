---
title: "Sayfa Prompt — Ana Sayfa"
category: page-prompt
version: "1.0.0"
date: "2026-08-11"
route: "/"
layout: "split-home-42-58"
---

# Ana Sayfa (Home Page)

## Route: `/`
## Layout Pattern: Split Home (42/58)

## Bileşen Listesi

| Bileşen | Adet | Konum | Açıklama |
|---------|------|-------|----------|
| C01 Header | 1 | Üst (h=56) | Logo, arama, profil |
| C02 Now Playing Card | 1 | Sol üst | Şu an çalan şarkı |
| C03 Mini Card | 1 | Sol | Albüm/küçük kart |
| C09 Card | 8 | Sol alt | Albüm/sanatçı kartları |
| Widget Area | 4 | Sağ | Glass paneller |
| C14 Mini Player | 1 | Alt (h=64) | Footer player |

## Sol Alan (42% = 430px)

1. **Now Playing Card (C02)** — Üstte, şu an çalan şarkıyı gösterir
2. **Mini Card (C03)** — Now Playing altında, albüm/küçük kart
3. **C09 Kartlar (×8)** — Alt kısımda, 2×4 grid

## Sağ Alan (58% = 578px) — Widget Alanı

4 glass panel widget:
1. **Widget 1:** Mini kart grubu (C09×2)
2. **Widget 2:** Son çalınanlar listesi
3. **Widget 3:** Öneri listesi
4. **Widget 4:** Hızlı erişim butonları

## ASCII Art Referansı

`00-mockup-index.md` §4.1 — Home Page ASCII Art

## Glass Panel Stili

```css
.widget {
  background: rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(16px);
  border-radius: 16px;
  border: 1px solid rgba(255, 255, 255, 0.1);
}
```
