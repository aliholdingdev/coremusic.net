---
type: reference
category: ui-design
title: "CoreMusic — Mockup Index (18 PNG, home-1024, Linux Embedded RPi5)"
date: 2026-08-11
updated: 2026-08-11
status: active
version: 3.0.0
authority: Single Source of Truth (SSOT)
governance: Red Team · Human Mode · Truth Mode
references:
  - [[01-component-inventory]]
  - [[02-implementation-plan]]
  - [[03-accessibility-gaps]]
  - [[04-vault-registration]]
  - [[architecture/l3-presentation]]
  - [[decisions/accepted/ADR-001-vanilla-js-itcss]]
  - [[decisions/accepted/ADR-044-dynamic-user-theme-engine]]
---

# CoreMusic — Mockup Index (v3.0.0)

**18 PNG mockup'ın kanonik indeksi.** Bundan sonra her frontend görevinin başlangıç noktası bu dosyadır.

> **⚠️ Mockup Before Frontend:** CSS/HTML/JS/layout/bileşen görevlerinde bu dosyadaki ilgili görsel okunmadan kod yazılamaz. Görsel okunamıyorsa DUR ve bildir.

---

## 1. Platform Tanımı

### 1.1 — Dizin İsimlendirmesi Anlamı

```
.ai/.png/{subdomain}-{resolution}/
                 ↑              ↑
                 │              └── Çözünürlük (1024=1024×600, 1920=1920×1080, 3840=3840×2160)
                 └── Subdomain (home, pro, studio, shared)
```

| Dizin | Subdomain | Çözünürlük | Cihaz | OS | Durum |
|-------|-----------|-----------|-------|-----|-------|
| `home-1024/` | home.coremusic.net | 1024×600 | RPi5 7" dokunmatik | Linux Embedded | ✅ 12 PNG |
| `shared-1024/` | Tüm subdomain'ler (auth) | 1024×600 | RPi5 7" dokunmatik | Linux Embedded | ✅ 6 PNG |
| `home-1920/` | home.coremusic.net | 1920×1080 | PC/Laptop | Windows/Linux | PLANLANDI |
| `home-3840/` | home.coremusic.net | 3840×2160 | 4K TV | Tizen/WebOS | PLANLANDI |
| `pro-1024/` | pro.coremusic.net | 1024×600 | RPi5 7" dokunmatik | Linux Embedded | PLANLANDI |
| `pro-1920/` | pro.coremusic.net | 1920×1080 | PC/Laptop | Windows/Linux | PLANLANDI |
| `studio-1024/` | studio.coremusic.net | 1024×600 | RPi5 7" dokunmatik | Linux Embedded | PLANLANDI |
| `studio-1920/` | studio.coremusic.net | 1920×1080 | PC/Laptop | Windows/Linux | PLANLANDI |
| `shared-1920/` | Tüm subdomain'ler (auth) | 1920×1080 | PC/Laptop | Windows/Linux | PLANLANDI |

### 1.2 — Bu Dosyanın Kapsadığı Platform

| Özellik | Değer |
|---------|-------|
| **Platform** | Linux Embedded (Raspberry Pi 5) |
| **Çözünürlük** | 1024 × 600 px |
| **Cihaz Tipi** | 7" dokunmatik ekran |
| **Girdi** | Parmak (fare yok, klavye yok, hover yok) |
| **Subdomain** | `home.coremusic.net` |
| **Device Type** | `device_type = 'embedded'` |
| **CSS Bundle** | `d-embedded.css` (ITCSS 08_Devices) |
| **Accent Rengi** | `#ff4fd8` (pembe — ADR-044 tema motoru ile değiştirilebilir) |
| **Gövde Fontu** | Arima |
| **Logo Fontu** | Bickham Script Two |
| **Arka Plan** | Tam kaplama fotoğraf + `backdrop-filter` cam efekti |

### 1.3 — Platform Bazlı Farklılıklar

| Özellik | home-1024 (RPi5) | home-1920 (Desktop) | home-3840 (4K TV) | Tizen TV | Native Mobile |
|---------|-----------------|-------------------|-------------------|----------|---------------|
| Header yüksekliği | 60px | 70px | 90px | 80px | 56px |
| Footer yüksekliği | 90px | 104px | 138px | 120px | 72px |
| Touch target | ≥48px | ≥44px (fare) | ≥44px (uzaktan) | ≥60px (uzaktan) | ≥48px |
| Font ölçeği | 1× | 1.2× | 1.6× | 1.4× | 1× |
| Sidebar | Sadece Göz At | Sadece Göz At | Sadece Göz At | Sadece Göz At | Modal |
| Glass efekti | blur(20px) | blur(20px) | blur(4px) | blur(4px) | Yok |
| Hover | Yok | Var | Yok (uzaktan) | Yok (uzaktan) | Yok |
| Grid sütun | 3 max | 4 max | 5 max | 4 max | 2 max |

---

## 2. Doğrulanmış Ölçüler (Piksel Düzeyinde)

### 2.1 — Tüm Ekranlarda Sabit (home-1024)

| Bölge | Değer | Y Koordinatı | Kaynak |
|-------|-------|-------------|--------|
| **Ekran** | 1024 × 600 px | — | PNG doğrulama |
| **Header** | 60px yükseklik | y: 0–60 | PNG ölçümü |
| **İçerik bölgesi** | 450px yükseklik | y: 60–510 | PNG ölçümü |
| **İçerik paneli** | — | y: 71–495 | PNG ölçümü (üstte 11px, altta 15px) |
| **Footer / Player** | 90px yükseklik | y: 510–600 | PNG ölçümü |
| **Footer üst kenarı** | y=510 | — | İlerleme çubuğu burada |
| **Oynatma daireleri** | 33px çap | y: 533–566 | PNG ölçümü |
| **Accent rengi** | `#ff4fd8` | — | ADR-044 |
| **Gövde fontu** | Arima | — | PNG doğrulama |
| **Logo fontu** | Bickham Script Two | — | PNG doğrulama |
| **Arka plan** | Tam kaplama fotoğraf | — | PNG doğrulama |

### 2.2 — Çelişkiler (Karar Bekleniyor)

| # | Çelişki | Kaynak A | Kaynak B | Öneri | Karar |
|---|---------|----------|----------|-------|-------|
| 1 | Footer: 90px vs 104px | PNG ölçümü (90px) | `a-layout-tokens.css:25` `--footer-h-compact: 104px` | **90px** — mockup esas, token güncellenir | BEKLİYOR |
| 2 | Sidebar: 167px vs 280px | PNG ölçümü (167px) | `a-layout-tokens.css` `--sidebar-w: 280px` | **167px** — sadece Göz At'a özel, global değil | BEKLİYOR |
| 3 | Sidebar global mi? | Mockup: Sadece Göz At | `_home-layout.css` sidebar global | **Sadece Göz At** — `.browse-layout` | BEKLİYOR |
| 4 | `d-embedded.css` footer token'ı | CSS: 104px | PNG: 90px | CSS güncellenmeli (90px) | BEKLİYOR |
| 5 | Auth akışı sırası | PNG'ler: Select Gender ilk | Mevcut kod: Login ilk | **Select Gender ilk** — tema rengi için gerekli | BEKLİYOR |

---

## 3. Ekran Envanteri — home-1024 (12 PNG)

### 3.1 — Uygulama Ekranları

| # | Ekran | PNG Dosyası | Rota | Layout Pattern | CSS Hedefi |
|---|-------|-------------|------|---------------|------------|
| 1 | **Ana Sayfa** | `Linux 1024 - Home Page.png` | `/` | Pattern 2: Split Home (42/58) | `05_Pages/_home-*.css` |
| 2 | **Hoş Geldin Modalı** | `Linux 1024 - Home Page Welcome Popup.png` | `/` (ilk giriş) | Pattern 4: Modal (600×308) | `05_Pages/_home-*.css` |
| 3 | **Albümler** | `Linux 1024 - Albumler Page.png` | `/albums` | Pattern 1: Standard 60/40 | `05_Pages/_home-*.css` |
| 4 | **Albüm Detayı** | `Linux 1024 - Albumler Details Detay Page.png` | `/album/:id` | Pattern 1: Standard 60/40 | `05_Pages/_home-*.css` |
| 5 | **Sanatçılar** | `Linux 1024 - Singer Page.png` | `/artists` | Pattern 1: Standard 60/40 | `05_Pages/_home-*.css` |
| 6 | **Playlist** | `Linux 1024 - Playlist Page.png` | `/playlist/:id` | Pattern 1: Standard 60/40 | `05_Pages/_home-*.css` |
| 7 | **Video Playback** | `Linux 1024 - Playlist Page - Video Played.png` | `/playlist/:id` (video) | Pattern 3: Fullscreen | `05_Pages/_home-*.css` |
| 8 | **Göz At (Disk)** | `Linux 1024 - Göz At Page.png` | `/browse` | Pattern 1: 3 Sütun (167+573+220) | `05_Pages/_home-*.css` |
| 9 | **Göz At (Tıklama)** | `Linux 1024 - Göz At - Tıklama Clikced.png` | `/browse` | Pattern 1: 3 Sütun | `05_Pages/_home-*.css` |
| 10 | **WiFi Modal** | `Linux 1024 - Wifi Qucik Page Base.png` | overlay | Pattern 4: Modal | `04_Components/c-modal.css` |
| 11 | **WiFi Bağlan** | `Linux 1024 - Wifi Coonect Light.png` | overlay (sub-dialog) | Pattern 4: Modal | `04_Components/c-modal.css` |
| 12 | **Bluetooth Modal** | `Linux 1024 - Bluethoot Qucik Page Base.png` | overlay | Pattern 4: Modal | `04_Components/c-modal.css` |

### 3.2 — Auth Ekranları (6 PNG — shared-1024)

| # | Ekran | PNG Dosyası | Sıra | Layout Pattern |
|---|-------|-------------|------|---------------|
| 13 | **Select Gender** | `Linux 1024 - Select Gender.png` | **1 (İLK)** | Pattern 5: Auth (78/22) |
| 14 | **Select Gender (Selected)** | `Linux 1024 - Select Gender - selected.png` | 1 (seçili hal) | Pattern 5: Auth |
| 15 | **Login** | `Linux 1024 - Login Girl.png` | **2** | Pattern 5: Auth (78/22) |
| 16 | **Register Step 1** | `Linux 1024 - Register Girl.png` | **3a** | Pattern 5: Auth (78/22) |
| 17 | **Register Step 2** | `Linux 1024 - Register Girl step 2.png` | **3b** | Pattern 5: Auth (78/22) |
| 18 | **Register Step 3** | `Linux 1024 - Register Girl step 3.png` | **3c** | Pattern 5: Auth (78/22) |

### 3.3 — Auth Akış Sırası (Doğrulanmış)

```
Select Gender (13) → Devam Et → Login (15) → Giriş Yap veya Kayıt Ol
                                                          ↓
                                              Register Step 1 (16) → Devam Et
                                                          ↓
                                              Register Step 2 (17) → Devam Et
                                                          ↓
                                              Register Step 3 (18) → Kayıt Ol → Tamamlandı
```

> **⚠️ DİKKAT:** Select Gender İLK adımdır. Cinsiyet seçimi tema rengini belirler (female→pink, male→blue, neutral→default). Bu sıra değiştirilemez.

---

## 4. ASCII Art — Tüm Ekranlar (Piksel Düzeyinde)

### 4.1 — HOME PAGE (Ana Sayfa) — PNG #1

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ x:0                                                                                     x:1024│
│ y:0 ┌─────────────────────────────────────────────────────────────────────────────────────────┐ │
│     │"Core Music"  Ana Sayfa  Keşfet  Albümler  Sanatçılar  Göz At  Geçmiş  Ayarlar  Hakk..│ │
│     │ y:15    (Bickham)  (nav-link × 8, gap:2-4px, Arima 10px)           [Bayram Ali ▾]    │ │
│     │                                                         [📶✳ pill 65×37] [🔋 pill 100]│ │
│     │ y:35                                                              [⚙] [⏻]             │ │
│ y:60├─────────────────────────────────────────────────────────────────────────────────────────┤ │
│     │                                                                                         │ │
│     │ x:16                                                                                    │ │
│     │ y:71 ┌──────────────────────────────────┐   ┌──────────────────────────────────────────┐│ │
│     │       │  ┌────────┐ Göksel - Sevil Neşelen│   │ 🎵 Hoparlörler                        ││ │
│     │       │  │100×100 │ Hayat Rüya Gibi       │   │    Core Music - Hoparlör               ││ │
│     │       │  │album   │ Göksel                │   │    ┌──────────────────────────────┐    ││ │
│     │       │  │art     │                       │   │    │ glass panel ~250×80           │    ││ │
│     │       │  └────────┘ 00:05:00 ═══════ 00:05│   │    └──────────────────────────────┘    ││ │
│     │       │              ▲ pembe seek bar h:3px│   │                                      ││ │
│     │       │                                   │   │ ☁ Hava Durumu                        ││ │
│     │       │  "En Son Dinlenen" başlığı        │   │    Hava Durumu Görseli               ││ │
│     │       │  ┌──────┐┌──────┐┌──────┐┌──────┐│   │    İzmir, TR                         ││ │
│     │       │  │140×  ││140×  ││140×  ││140×  ││   │    ┌──────────────────────────────┐    ││ │
│     │       │  │140   ││140   ││140   ││140   ││   │    │ glass panel ~250×80           │    ││ │
│     │       │  │C09   ││C09   ││C09   ││C09   ││   │    └──────────────────────────────┘    ││ │
│     │       │  │kart  ││kart  ││kart  ││kart  ││   │                                      ││ │
│     │       │  └──────┘└──────┘└──────┘└──────┘│   │ 📅 07:00                              ││ │
│     │       │                                   │   │    5 Ağustos 2026                     ││ │
│     │       │  "Oynatma Listeleri" başlığı      │   │    ┌──────────────────────────────┐    ││ │
│     │       │  ┌──────┐┌──────┐┌──────┐┌──────┐┌│   │    │ glass panel ~250×80           │    ││ │
│     │       │  │140×  ││140×  ││140×  ││140×  │││   │    └──────────────────────────────┘    ││ │
│     │       │  │140   ││140   ││140   ││140   │││   │                                      ││ │
│     │       │  │kart  ││kart  ││kart  ││kart  │││   │ 📂 Klasörlerim                       ││ │
│     │       │  └──────┘└──────┘└──────┘└──────┘││   │    [▶][YT][♥][♫][♥]                  ││ │
│     │       │  ☐ "Oynatma listesini göster"     │   │    ┌──────────────────────────────┐    ││ │
│     │       │                                   │   │    │ glass panel ~250×80           │    ││ │
│     │       │  "Sıradaki Şarkılar"              │   │    └──────────────────────────────┘    ││ │
│     │       │                                   │   └──────────────────────────────────────────┘│ │
│     │       │                       ┌─ Mini Card ──────────────────────┐                       │ │
│     │       │                       │ [50×50] Göksel                    │                       │ │
│     │       │                       │          Sevil Neşelen             │                       │ │
│     │       │                       │          Hayat Rüya Gibi           │                       │ │
│     │ y:495 │                       └───────────────────────────────────┘                       │ │
│     └─────────────────────────────────────────────────────────────────────────────────────────┘ │
│ y:510├─────────────────────────────────────────────────────────────────────────────────────────┤ │
│     │▲ pembe ilerleme çubuğu h:3px, full-width, y=0                                            │ │
│     │ y:513┌────────┐ ♪ Şarkı Adı  : Göksel - Sevil Neşelen                                   │ │
│     │       │120×120 │ ● Albümüm   : Hayat Rüya Gibi                                           │ │
│     │       │album   │ 🎤 Sanatçı  : Göksel                                                   │ │
│     │       │art     │                                                                         │ │
│     │ y:550└────────┘    [⏮]  [▶]  [⏹]  [⏭]     Süre: 09:00:00 / 00:05:00                   │ │
│     │                       ◯    ◉    ◯    ◯      Bit rate : 320 kbps                         │ │
│     │ y:566                   (33px çap daireler)    [🔊 ═══▲═══ ] % 100                       │ │
│ y:600└─────────────────────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘

Bileşenler: C01×8, C02, C03, C09×~14, Now Playing Card, Widget Area (4×glass), Mini Card, Footer Player
Layout: Split — Sol %42 (Now Playing + kartlar) / Sağ %58 (Widget'lar)
Sidebar: YOK (global sidebar token'ı kullanılmaz)
```

---

### 4.2 — HOŞ GELDİN MODALI — PNG #2

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [HEADER — arka plan bulanık, backdrop-filter: blur(4px)]                                       │
│ [ANA SAYFA — arka plan bulanık, rgba(0,0,0,0.5)]                                              │
│                                                                                                 │
│     x:212                                                                                       │
│ y:145 ┌─────────────────────────────────────────────────────────────────────────────────────┐   │
│       │                                                                                     │   │
│       │                [CoreMusic Logo — 60×40px, orta hizalı]                             │   │
│       │                Hoş geldin                                                           │   │
│       │ y:190                                                                              │   │
│       │                *İsminizi Girin Buraya*                                              │   │
│       │                (Bickham Script Two, italik, pembe, ~16px)                           │   │
│       │ y:220                                                                              │   │
│       │    Sana özel seçimler, müzik deneyimlerini ve sunumları                            │   │
│       │    tamamen sana özel hale getirir. CoreMusic ile rüyalarındaki                     │   │
│       │    müziğin Keyfine dal ♡                                                           │   │
│       │ y:280                                                                              │   │
│       │                ┌─────────────┐                                                      │   │
│       │                │   Başla     │  105×25px (WCAG İHLALİ: 48px olmalı)                │   │
│       │                │  #ff4fd8    │  pembe arka plan, beyaz text                         │   │
│       │ y:310          └─────────────┘                                                      │   │
│       │                                                                                     │   │
│ y:453 └─────────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                                 │
│ Modal: 600×308px, glass efekti, backdrop-filter: blur(20px) saturate(180%)                     │
│ Modal border: 1px solid rgba(255,255,255,0.1)                                                 │
│ Modal border-radius: 16px                                                                       │
│ Overlay: rgba(0,0,0,0.5) + backdrop-filter: blur(4px)                                         │
│ Merkez: x=512, y=299.5                                                                         │
│ Kapat: backdrop click                                                                           │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.3 — ALBÜMLER PAGE — PNG #3

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [HEADER — ortak, y:0-60]                                                                        │
├─────────────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                                 │
│ x:16 y:71 ← Albümler / Tüm Albümler                            [Sanatçı Adı Ara 🔍] [≡]     │
│ y:91 "Albümler"                                                                                │
│ y:105 Kütüphanede depolanan tüm albümler                                                       │
│                                                                                                 │
│ y:120 [Tümü][Pop][Arabesk][Dans][Oyun Havası][Damar][Org][Yabancı Pop][Kpop/Kore]...          │
│        ^^^ C11 Genre Tabs — ~13 sekme, h:32px (WCAG: 48px), gap:4px, yatay scroll             │
│        Aktif: pembe arka plan (#ff4fd8)                                                        │
│                                                                                                 │
│ y:160 ┌── CARD GRID (x:16-630, w:614px) ──┐  ┌── DETAIL PANEL (x:642-1008, w:366px) ───────┐│
│        │ ┌───────┐┌───────┐┌───────┐       │  │          ┌──────────┐                         ││
│        │ │140×140││140×140││140×140│       │  │          │ 圆形 300  │  Nobetci Eczane        ││
│        │ │ album ││ album ││ album │       │  │          │ ×300      │  Ferhat Kasetleri      ││
│        │ │ thumb ││ thumb ││ thumb │       │  │          │ (r:50%)   │  Kaset                 ││
│        │ │───────││───────││───────│       │  │          └──────────┘                         ││
│        │ │Nobetci││Bergen ││Civaner│       │  │                                                ││
│        │ │Eczane ││-Tüm   ││-Tüm   │       │  │  ┌──────────────────────────────────────┐    ││
│        │ │Ferhat ││Şarkıla││Şarkıl │       │  │  │     Hemen Çal (C04, pembe, full-w)   │    ││
│        │ │Kasetle││rı     ││ar     │       │  │  └──────────────────────────────────────┘    ││
│        │ │ri     ││00:10: ││00:10: │       │  │  ┌──────────────────────────────────────┐    ││
│        │ │00:10: ││05     ││05     │       │  │  │     Karışık Çal (C05, sınır, full-w) │    ││
│        │ │05     ││       ││       │       │  │  └──────────────────────────────────────┘    ││
│        │ └───────┘└───────┘└───────┘       │  │  [...] (daha fazla)                          ││
│        │ 3 sütun × 3 satır = 9 kart        │  │                                                ││
│        │ gap: 8px                           │  │  Kalite: 24 Bit / 48 kHz                    ││
│        │                                    │  │  Boyut: 2 GB | İndirme: 2                    ││
│        │                                    │  │  Parça: 12 | Tür: Arabesk                    ││
│        │                                    │  │  Yıl: Bilinmeyen Yıl                        ││
│        │                                    │  │  Dinlenme Sayısı: 5                         ││
│ y:495  └────────────────────────────────────┘  │  Süre: 00:30:00                             ││
│                                                └────────────────────────────────────────────────┘│
│ [FOOTER — ortak, y:510-600]                                                                    │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘

Layout: Standard 60/40 — Sol 614px (card grid) + Sağ 366px (detail panel)
Grid: 3 sütun, gap:8px, kart boyutu ~140×180px (thumb 140×140 + text altı)
```

---

### 4.4 — ALBÜM DETAY — PNG #4

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [HEADER]                                                                                        │
├─────────────────────────────────────────────────────────────────────────────────────────────────┤
│ x:16 y:71 ← Album Detayları                                    [Şarkı Ara 🔍]               │
│ y:100 Albüm : Göksel - Hayat Rüya Gibi    /    Şarkı Adı       Süre     Favori Yıldızı        │
│                                                                                                 │
│ y:120 ┌─────────────────────────────────────────────────────────────────────────────────────┐   │
│        │ [♪] Göksel - Sevil Neşelen                           00:05:00  ★★★★★             │   │
│        │ [♪] Göksel - Kabahat Senin                           00:00:00  ★★★★★             │   │
│        │ [♪] Göksel - Sevil Neşelen                           00:00:00  ★★★★★             │   │
│        │ [♪] Göksel - Sevil Neşelen                           00:00:00  ★★★★☆             │   │
│        │ [♪] Göksel - Sevil Neşelen ← PEMBE VURGU             00:00:00  ★★★★★             │   │
│        │ [♪] Göksel - Sevil Neşelen                           00:00:00  ★★★★★             │   │
│        │ [♪] Göksel - Sevil Neşelen                           00:00:00  ★★★★★             │   │
│ y:350  └─────────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                                 │
│ y:360 ┌─ Sol Alt (~70%) ───────────────────┐  ┌─ Sağ Panel (x:784-1008, ~30%) ────────────┐   │
│        │ [圆形 Album Art]                    │  │  ┌────────────┐                             │   │
│        │ Hayat Rüya Gibi                     │  │  │ 圆形 300×300│  Hayat Rüya Gibi          │   │
│        │ Göksel ★★★★★                        │  │  │ Album Art   │  Göksel                   │   │
│        │ 350 Kbps (gizli)                    │  │  └────────────┘                             │   │
│        │ 2024 · 12 Şarkı · 00:30:00 · Pop   │  │  [Hemen Çal] (C04, pembe)                  │   │
│        │                                     │  │  [Karışık Çal] (C05, sınır) [...]           │   │
│        │                                     │  │  Kalite: 24 Bit / 48 kHz                   │   │
│        │                                     │  │  Boyut: 3 GB | İndirme: 2                   │   │
│        │                                     │  │  Parça: 11 | Tür: Arabesk                   │   │
│        │                                     │  │  Yıl: Bilinmeyen | Dinlenme: 10             │   │
│ y:495  └─────────────────────────────────────┘  │  Süre: 00:30:00                             │   │
│                                                  └──────────────────────────────────────────────┘   │
│ [FOOTER]                                                                                        │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘

Layout: Standard 60/40 — Sol ~70% (track list + metadata) / Sağ ~30% (detail panel)
Aktif satır: pembe arka plan rgba(255,79,216,0.15)
```

---

### 4.5 — SANATÇILAR — PNG #5

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [HEADER]                                                                                        │
├─────────────────────────────────────────────────────────────────────────────────────────────────┤
│ x:16 y:71 ← Sanatçılar / Tüm Sanatçılar                        [Sanatçı Adı Ara 🔍] [≡]    │
│ y:120 [Tümü][Pop][Arabesk][Dans][Oyun Havası][Damar][Org][Yabancı Pop][Kpop/Kore]...          │
│                                                                                                 │
│ y:160 ┌── CARD GRID (sol ~60%) ──────────────┐  ┌── DETAIL PANEL (sağ ~40%) ──────────────┐  │
│        │                                       │  │  ┌────────────┐                          │  │
│        │  Dairesel kartlar (border-radius: 50%)│  │  │ 圆形 300×300│  Sibel Can             │  │
│        │                                       │  │  │ Artist Photo│  Türkçe Pop             │  │
│        │  ┌────────┐ ┌────────┐ ┌────────┐   │  │  │ (r:50%)     │  1044 Şarkı             │  │
│        │  │ ○○○○○  │ │ ○○○○○  │ │ ○○○○○  │   │  │  └────────────┘                          │  │
│        │  │ Sibel  │ │Dilso'z │ │Ankara- │   │  │  ♫ 48  🎵 8  📅 1988                    │  │
│        │  │  Can   │ │        │ │lı Ayşe │   │  │  [bio metni — 3-4 satır açıklama]        │  │
│        │  │Türkçe  │ │Türkçe  │ │Oyun    │   │  │                                          │  │
│        │  │ Pop    │ │ Pop    │ │Havası  │   │  │  [Hemen Çal] (C04, pembe)                 │  │
│        │  │45 Şar. │ │48 Şar. │ │42 Şar. │   │  │  [Karışık Çal] (C05, sınır) [...]        │  │
│        │  └────────┘ └────────┘ └────────┘   │  │                                          │  │
│        │  ┌────────┐ ┌────────┐              │  │                                          │  │
│        │  │ ○○○○○  │ │ ○○○○○  │              │  │                                          │  │
│        │  │Ankara- │ │Bergen  │              │  │                                          │  │
│        │  │lı Ya-  │ │        │              │  │                                          │  │
│        │  │semin   │ │Arabesk │              │  │                                          │  │
│        │  └────────┘ └────────┘              │  │                                          │  │
│ y:495  └──────────────────────────────────────┘  └──────────────────────────────────────────┘  │
│ [FOOTER]                                                                                        │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘

FARK: Kartlar DAİRESEL (border-radius: 50%), Albums'de KARE
Layout: Standard 60/40
```

---

### 4.6 — PLAYLIST — PNG #6

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [HEADER]                                                                                        │
├─────────────────────────────────────────────────────────────────────────────────────────────────┤
│ x:16 y:71 ← Şimdi Oynatılıyor                                  [Şarkı Ara 🔍]               │
│                                                                                                 │
│ y:100 ┌── TABLO (x:16-680, ~65%) ──────────────────────────────────────────────────────────┐  │
│        │ / | Şarkı Adı         | Albüm Adı        | Sanatçı | Süre    | Favori Yıldızı    │  │
│        │───│───────────────────│──────────────────│─────────│─────────│──────────────────│  │
│        │[♪]│Göksel-Sevil Neş.  │Hayat Rüya Gibi   │Göksel   │00:00:00│ ★★★★★           │  │
│        │[♪]│Göksel-Sevil Neş.  │Hayat Rüya Gibi   │Göksel   │00:00:00│ ★★☆☆☆           │  │
│        │[♪]│Göksel-Sevil Neş.  │Hayat Rüya Gibi   │Göksel   │00:00:00│ ★★★★★           │  │
│        │[♪]│Göksel-Sevil Neş.  │Hayat Rüya Gibi   │Göksel   │00:00:00│ PEMBE VURGU     │  │
│        │[♪]│Göksel-Sevil Neş.  │Hayat Rüya Gibi   │Göksel   │00:00:00│ ★★★★★           │  │
│        │[♪]│Göksel-Sevil Neş.  │Hayat Rüya Gibi   │Göksel   │00:00:00│ ★★★★★           │  │
│        │[♪]│Göksel-Sevil Neş.  │Hayat Rüya Gibi   │Göksel   │00:00:00│ ★★★★★           │  │
│ y:495  └────────────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                                 │
│ y:100 ┌── SAĞ PANEL (x:700-1008, ~300px) ────────────────────────────────────────────────┐    │
│        │ [圆形 Artist Photo 100×100]                                                        │    │
│        │ Göksel - Sevil Neşelen                                                            │    │
│        │ Göksel, Hayat Rüya Gibi                                                           │    │
│        │                                                                                    │    │
│        │ [♫][♥][▼][⋯]  (aksiyon ikonları, 44×44px hit area)                               │    │
│        │                                                                                    │    │
│        │ Önerilen Sanatçılar          Takip Edilen Sanatçılar                              │    │
│        │ [thumb×4 grid]               [thumb×4 grid]                                        │    │
│        │                                                                                    │    │
│        │ Son Öneriler                 Tüm Sanatçılar                                       │    │
│        │ [thumb×4 grid]               [thumb×4 grid]                                        │    │
│ y:495  └────────────────────────────────────────────────────────────────────────────────────┘   │
│ [FOOTER]                                                                                        │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘

Layout: Standard 60/40 — Sol ~65% (tablo) / Sağ ~300px (detail panel)
Aktif satır: pembe arka plan
Tablo başlığı: sabit üstte, sıralanabilir
```

---

### 4.7 — VIDEO PLAYBACK (Fullscreen) — PNG #7

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ ← Göksel - Sevil Neşelen (x:16, y:16, geri ok 44×44px)                                       │
│ Header: YOK (sadece geri ok)                                                                   │
│                                                                                                 │
│ y:60 ┌── VİDEO (x:0-717, w:717px) ──────────┐  ┌── LİSTE (x:717-1024, w:307px) ──────────┐ │
│        │                                       │  │ Şarkı Adı                    Süre         │ │
│        │   [Tam kaplama video/image]            │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│        │   background-size: cover               │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│        │   background-position: center          │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│        │                                        │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│        │                                        │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│        │                                        │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│        │                                        │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│        │                                        │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│        │                                        │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│        │                                        │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│        │                                        │  │ [thumb] Göksel - Sevil Neş.  00:00:00    │ │
│ y:510  └────────────────────────────────────────┘  └──────────────────────────────────────────┘ │
│                                                                                                 │
│ y:430 ┌─ Mini Player (sol alt, ~300×100px) ─────────────────────────────────────────────────┐  │
│        │ [50×50 thumb] Göksel - Sevil Neşelen                                              │  │
│        │                Hayat Rüya Gibi                                                     │  │
│        │                Göksel                                                               │  │
│        │                00:00:00 / 00:05:00                                                 │  │
│        │                [seek bar — full-width, h:3px]                                      │  │
│ y:530  └────────────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                                 │
│ y:580 m3p3 ★★★★★                                                                              │
│ Footer: YOK (mini player ile değiştirildi)                                                     │
│ ARKA PLAN: Tam kaplama sanatçı fotoğrafı                                                      │
│ Sağ panel: Yarı saydam, glass efekti                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.8 — GÖZ AT (Disk) — PNG #8

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [HEADER]                                                                                        │
├─────────────────────────────────────────────────────────────────────────────────────────────────┤
│ x:16 y:71 ← Dosya Yöneticisi / Disk                              [c:\users\...\Music] 🔍    │
│                                                                                                 │
│ y:100 ┌─ SOL SIDEBAR (x:16-183, w:167px) ──┐  ┌─ ORTA LİSTE (x:186-759, w:573px) ────────┐  │
│        │ Sistem Diskleri                     │  │ Şarkı Adı      | Albüm Adı | Sanatçı | Süre│  │
│        │  ● System Disk                      │  │ [♪] Pop Şarkıları Ali                     │  │
│        │  ● NAS Drive                        │  │ [♪] Göksel - Sevil Neş. | Hayat Rüya | ...│  │
│        │                                     │  │ [♪] Göksel - Sevil Neş. | Hayat Rüya | ...│  │
│        │ Harici / Taşınabilir Diskler        │  │ [♪] Göksel - Sevil Neş. | Hayat Rüya | ...│  │
│        │  ● HDD Drive                        │  │                                             │  │
│        │  ● SSD Nvme 2 Drive                 │  │                                             │  │
│        │  ● SSD Drive                        │  │                                             │  │
│        │                                     │  │                                             │  │
│        │ Çıkarılabilir Diskler               │  │                                             │  │
│        │  ● USB Drive                        │  │                                             │  │
│        │  ● USB Drive                        │  │                                             │  │
│        │  ● CD DVD Drive                     │  │                                             │  │
│ y:495  └─────────────────────────────────────┘  └───────────────────────────────────────────┘  │
│                                                                                                 │
│ y:100 ┌─ SAĞ BİLGİ (x:784-1008, w:224px) ────────────────────────────────────────────────┐   │
│        │ System Disk                                                                        │   │
│        │ Hard Disk · Dahili Disk                                                            │   │
│        │ ┌──────────┐                                                                       │   │
│        │ │Donut Chart│ 32 GB — 16 GB Kullanılabilir %50                                     │   │
│        │ └──────────┘                                                                       │   │
│        │ [Göz At] (C04, pembe, full-width)                                                  │   │
│        │ [Bütün Şarkıları Çal] (C05, sınır)                                                │   │
│        │ [Şarkıları Göz At] (C05, sınır)                                                   │   │
│        │ [Şarkılarını Göz At] (C05, sınır)                                                 │   │
│        │ [Videoları Göz At] (C05, sınır)                                                   │   │
│ y:495  └────────────────────────────────────────────────────────────────────────────────────┘   │
│ [FOOTER]                                                                                        │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘

Layout: 3 Sütun — Sol 167px (disk listesi) + Orta 573px (dosya listesi) + Sağ 224px (bilgi)
Sidebar: SADECE BU SAYFAYA ÖZEL (global değil)
```

---

### 4.9 — GÖZ AT TIKLAMA — PNG #9

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [HEADER]                                                                                        │
├─────────────────────────────────────────────────────────────────────────────────────────────────┤
│ x:16 ← → Dosya Yöneticisi / Musics : Root  c:\users\Bayram Ali\Music  [Dosya Ara 🔍]         │
│                                                                                                 │
│ y:100 ┌─ SOL (167px) ───────────────┐  ┌─ ORTA (573px) ───────────────────────────────────┐  │
│        │ ● Tüm Şarkılar      1000    │  │ Şarkı Adı      | Albüm Adı | Sanatçı | Süre     │  │
│        │ ● Son Eklenenler     100     │  │ [♪] Pop Şarkıları Ali                           │  │
│        │ ● Son Dinlenenler     50     │  │ [♪] Göksel - Sevil Neş. | Hayat Rüya | 00:00   │  │
│        │ ● Favoriler           20     │  │ [♪] Göksel - Sevil Neş. | Hayat Rüya | 00:00   │  │
│        │ ● Oynatma List.        5     │  │ [♪] Göksel - Sevil Neş. | Hayat Rüya | 00:00   │  │
│        │ ● Sanatçılar         100     │  │                                                 │  │
│        │ ● Albümler            40     │  │                                                 │  │
│        │ ● Türler              50     │  │                                                 │  │
│        │ ● Videolar           125     │  │                                                 │  │
│        │ ● Podcast             12     │  │                                                 │  │
│        │                           │  │                                                 │  │
│        │ Core Tropu               │  │                                                 │  │
│        │ ▼ System Disk (C:)      │  │                                                 │  │
│        │ ▼ USB Disk (E:) ← PEMBE │  │                                                 │  │
│ y:495  └───────────────────────────┘  └───────────────────────────────────────────────────┘  │
│                                                                                                 │
│ y:100 ┌─ SAĞ (224px) ──────────────────────────────────────────────────────────────────────┐  │
│        │ SSD Disk (E:)                                   [sil][düzenle][kopyala][yapış]    │  │
│        │ Sanat Güneştepe23                                                               │  │
│        │ ┌──────────┐                                                                       │  │
│        │ │Donut Chart│ 65 GB — Kullanılan 49.5 GB, Boş 15.5 GB                             │  │
│        │ └──────────┘                                                                       │  │
│        │ [Göz At] (C04, pembe)                                                              │  │
│        │ ── Disk Kullanım Bilgisi ──                                                        │  │
│        │ ┌─ Bar Charts ──┐  ┌─ Genre Pie ──┐                                               │  │
│        │ │ [mavi][pembe]  │  │ [pie chart]   │                                               │  │
│        │ │ [mavi][pembe]  │  │ Pop:1000      │                                               │  │
│        │ │ [mavi][pembe]  │  │ Arabesk:600   │                                               │  │
│        │ └────────────────┘  └───────────────┘                                               │  │
│ y:495  └────────────────────────────────────────────────────────────────────────────────────┘  │
│ [FOOTER]                                                                                        │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.10 — WIFI MODAL — PNG #10

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [HEADER — bulanık]                                                                              │
│ [ANA SAYFA — bulanık, backdrop-filter: blur(4px), rgba(0,0,0,0.5)]                            │
│                                                                                                 │
│     x:320                                                                                       │
│ y:130 ┌─────────────────────────────────────────────────────────────────────────────────────┐   │
│        │ [📶] Wi-Fi                                                                         │   │
│        │ Ağ Bağlantıları                                                                   │   │
│        │                                                                                    │   │
│        │ Wi-Fi  [━━━━━━○ toggle, 50×28px]                                                  │   │
│        │                                                                                    │   │
│        │ Bağlı Olan Ağ                                                                      │   │
│        │ ┌────────────────────────────────────────────────────────────────────────────┐     │   │
│        │ │ [📶] Bayram Ali Home [Güçlü] 5GHz · Mükemmel · 100%     [Bağlanıyo]      │     │   │
│        │ └────────────────────────────────────────────────────────────────────────────┘     │   │
│        │                                                                                    │   │
│        │ Kullanılabilir Ağlar                                                                │   │
│        │ ┌────────────────────────────────────────────────────────────────────────────┐     │   │
│        │ │ [📶] Bayram Ali Home [Güçlü] 5GHz · Mükemmel · 100%      [Bağlan]        │     │   │
│        │ │ [📶] Bayram Ali Home [Orta]  2.4GHz · İyi · 80%           [Bağlan]        │     │   │
│        │ │ [📶] Bayram Ali Home [Zayıf] [Gizli] 2.4GHz · Orta · 60%  [Bağlan]       │     │   │
│        │ └────────────────────────────────────────────────────────────────────────────┘     │   │
│        │                                                                                    │   │
│ y:470  └────────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                                 │
│ Modal: glass efekti, ~380×340px                                                               │
│ Badge renkleri: Güçlü=#22c55e, Orta=#eab308, Zayıf=#ef4444                                    │
│ Badge: pembe arka plan (Güçlü, Orta, Gizli)                                                   │
│ C16 Network Row satırları: ~48px yükseklik                                                    │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.11 — WIFI BAĞLAN — PNG #11

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [HEADER — bulanık]                                                                              │
│ [ANA SAYFA — bulanık]                                                                           │
│                                                                                                 │
│     x:320                                                                                       │
│ y:230 ┌─────────────────────────────────────────────────────────────────────────────────────┐   │
│        │ Bayram Ali - WiFi 📶                                                               │   │
│        │                                                                                    │   │
│        │ 5GHz · Mükemmel sinyal · 100% · Güçlü Bağlantı                                   │   │
│        │                                                                                    │   │
│        │ Kablosuz Ağ Şifresi                                                                │   │
│        │ ┌────────────────────────────────────────────────────────────────────────────┐     │   │
│        │ │ ●●●●●●●●  (C06 Form Input, 56px yükseklik)                                │     │   │
│        │ └────────────────────────────────────────────────────────────────────────────┘     │   │
│        │                                                                                    │   │
│        │ ☐ Kablosuz ağa her zaman otomatik bağlan                                          │   │
│        │                                                                                    │   │
│        │                          [İptal] (C05)  [Bağlan] (C04, pembe)                     │   │
│ y:370  └────────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                                 │
│ Modal: ~380×140px, glass efekti                                                               │
│ Sub-dialog: WiFi modal üzerine bindirme                                                       │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.12 — BLUETOOTH MODAL — PNG #12

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ [HEADER — bulanık]                                                                              │
│ [ANA SAYFA — bulanık, backdrop-filter: blur(4px), rgba(0,0,0,0.5)]                            │
│                                                                                                 │
│     x:320                                                                                       │
│ y:130 ┌─────────────────────────────────────────────────────────────────────────────────────┐   │
│        │ [✳] Bluetooth                                                                      │   │
│        │ Cihaz Bağlantıları                                                                 │   │
│        │                                                                                    │   │
│        │ Bluetooth  [━━━━━━○ toggle, 50×28px]                                              │   │
│        │                                                                                    │   │
│        │ Bağlı Olan Cihaz                                                                   │   │
│        │ ┌────────────────────────────────────────────────────────────────────────────┐     │   │
│        │ │ [✳] Kim - 50 [A2DP]  Tarayıcı · Pil: Dolu · 100%     [Bağlantıyı Kes]   │     │   │
│        │ └────────────────────────────────────────────────────────────────────────────┘     │   │
│        │                                                                                    │   │
│        │ Kullanılabilir Cihazlar                                                             │   │
│        │ ┌────────────────────────────────────────────────────────────────────────────┐     │   │
│        │ │ [✳] Kim - 50 [A2DP][HFP] Tarayıcı · Pil: Dolu · 100%     [Bağlan]       │     │   │
│        │ │ [✳] Car BT [A2DP][Müzik]   Tarayıcı · Pil: Dolu · 100%     [Bağlan]       │     │   │
│        │ │ [✳] Samsung TV [A2DP][HFP] Televizyon · Pil: Dolu · 100%   [Bağlan]       │     │   │
│        │ └────────────────────────────────────────────────────────────────────────────┘     │   │
│        │                                                                                    │   │
│ y:470  └────────────────────────────────────────────────────────────────────────────────────┘   │
│                                                                                                 │
│ Modal: ~380×340px, glass efekti                                                               │
│ Badge renkleri: A2DP=pembe, HFP=mor, Müzik=yeşil                                             │
│ C16 Device Row satırları: ~48px yükseklik                                                    │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.13 — SELECT GENDER — PNG #13 (İLK ADIM)

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Header: YOK (auth sayfası)                                                                     │
│ Footer: YOK (auth sayfası)                                                                     │
│                                                                                                 │
│ ┌── SOL ALAN (x:0-740, ~72%) ──────────────────────────────────────────────────────────────┐  │
│ │                                                                                            │  │
│ │   [Tam kaplama manzara fotoğrafı — sunset, okyanus, pembe tonları]                       │  │
│ │                                                                                            │  │
│ │   x:60 y:200                                                                              │  │
│ │   [CoreMusic Logo — Bickham Script Two]                                                   │  │
│ │   "Seni Tanıyalım"                                                                        │  │
│ │   Deneyimini sana özel hale getirmek için bir seçim yapman yeterli.                       │  │
│ │                                                                                            │  │
│ │                                                                                            │  │
│ │   x:60 y:400                                                                              │  │
│ │   "İyi ki Varsın Emanet!"                                                                 │  │
│ │   (Bickham Script Two, italik, dekoratif)                                                 │  │
│ │                                                                                            │  │
│ │                                                                                            │  │
│ │   x:60 y:520                                                                              │  │
│ │   "Müziğinle Hayat Buldum"                                                                │  │
│ │   "Hayatın rastlantılarla dolu..."                                                        │  │
│ │   (Bickham Script Two, italik, dekoratif)                                                 │  │
│ │                                                                                            │  │
│ └────────────────────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                                 │
│ ┌── SAĞ PANEL (x:740-1024, ~284px, glass) ─────────────────────────────────────────────────┐  │
│ │                                                                                            │  │
│ │   x:780 y:60                                                                              │  │
│ │   [Kadın ikonu — line art, beyaz]                                                         │  │
│ │   "Seni Tanıyalım"                                                                        │  │
│ │   "Müzik deneyimini sana özel hale getirelim"                                             │  │
│ │                                                                                            │  │
│ │   x:780 y:160                                                                             │  │
│ │   ┌──────────────────────────────────────────────────────────────┐                        │  │
│ │   │ [👩] Kız                                    C07 Gender Button │                        │  │
│ │   │        Temizlik, saf duygular               (~284×60px)     │                        │  │
│ │   │        Pembemsi renk tonları                                 │                        │  │
│ │   └──────────────────────────────────────────────────────────────┘                        │  │
│ │   ┌──────────────────────────────────────────────────────────────┐                        │  │
│ │   │ [👨] Erkek                                   C07 Gender Button│                        │  │
│ │   │        Güçlü, klasik tonlar                  (~284×60px)     │                        │  │
│ │   │        Mavimsi renk tonları                                 │                        │  │
│ │   └──────────────────────────────────────────────────────────────┘                        │  │
│ │   ┌──────────────────────────────────────────────────────────────┐                        │  │
│ │   │ [🤷] Cinsiyetimi belirtmek istemiyorum     C07 Gender Button│                        │  │
│ │   │        Nötr renk tonları                     (~284×60px)     │                        │  │
│ │   └──────────────────────────────────────────────────────────────┘                        │  │
│ │                                                                                            │  │
│ │   x:780 y:380                                                                             │  │
│ │   [Devam Et] butonu — Sadece sınır, pasif (seçim yapıldığında pembe olur)                │  │
│ │                                                                                            │  │
│ │   x:780 y:460                                                                             │  │
│ │   "Hayatın rastlantılarla dolu...                                                        │  │
│ │    senin gizli Müziğinle partala! ♥"                                                     │  │
│ │   (Bickham Script Two, dekoratif)                                                         │  │
│ │                                                                                            │  │
│ │   x:780 y:560                                                                             │  │
│ │   Devam ederek [Gizlilik Politikamızı] kabul etmiş olursunuz.                            │  │
│ │                                                                                            │  │
│ └────────────────────────────────────────────────────────────────────────────────────────────┘  │
│                                                                                                 │
│ Layout: 72/28 split — Sol manzara + Sağ glass panel                                            │
│ Glass panel: backdrop-filter: blur(20px) saturate(180%), yarı saydam                          │
│ Seçim yapıldığında: "Devam Et" butonu pembe olur (full-width)                                 │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.14 — SELECT GENDER (SELECTED) — PNG #14

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ PNG #13 ile AYNI, tek fark:                                                                    │
│                                                                                            │  │
│   "Kız" butonu SEÇİLİ:                                                                       │  │
│   ┌══════════════════════════════════════════════════════════════════════════════════┐       │  │
│   ║ [👩] Kız ← pembe arka plan (rgba(255,79,216,0.2)), 2px solid pembe border       ║       │  │
│   ║      Temizlik, saf duygular                                                     ║       │  │
│   ║      Pembemsi renk tonları                                                      ║       │  │
│   ══════════════════════════════════════════════════════════════════════════════════       │  │
│                                                                                            │  │
│   "Devam Et" butonu: ARTIK PEMBE (full-width, C04)                                         │  │
│   ┌──────────────────────────────────────────────────────────────┐                          │  │
│   │                    Devam Et                                   │                          │  │
│   │                    (full-width, pembe, 56px)                 │                          │  │
│   └──────────────────────────────────────────────────────────────┘                          │  │
│                                                                                            │  │
│ Diğer butonlar: seçilmemiş (border: 1px solid rgba(255,255,255,0.15))                      │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.15 — LOGIN — PNG #15

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Header: YOK                                                                                    │
│ Footer: YOK                                                                                    │
│                                                                                                 │
│ ┌── SOL ALAN (x:0-740, ~72%) ──┐  ┌── SAĞ PANEL (x:740-1024, ~284px, glass) ─────────────┐  │
│ │                                │  │                                                        │  │
│ │ [Manzara fotoğrafı]            │  │  [Kadın ikonu — line art]                             │  │
│ │                                │  │  "Hoş Geldin"                                         │  │
│ │ x:60 y:200                     │  │  "Hesabına giriş yap, müziğin keyfini çıkar."         │  │
│ │ [CoreMusic Logo]               │  │                                                        │  │
│ │ "Seni Tanıyalım"              │  │  x:780 y:160                                           │  │
│ │                                │  │  E-posta, Telefon veya Kullanıcı Adı                  │  │
│ │ x:60 y:400                     │  │  ┌──────────────────────────────────────────────┐     │  │
│ │ "İyi ki Varsın Emanet!"       │  │  │ E-postanızı yazınız             (C06, 56px) │     │  │
│ │                                │  │  └──────────────────────────────────────────────┘     │  │
│ │ x:60 y:520                     │  │  Şifre                                               │  │
│ │ "Müziğinle Hayat Buldum"      │  │  ┌──────────────────────────────────────────────┐     │  │
│ │                                │  │ │ ●●●●●●●●                          (C06, 56px) │     │  │
│ │                                │  │  └──────────────────────────────────────────────┘     │  │
│ │                                │  │                                                        │  │
│ │                                │  │  ☐ Hatırla Beni          [Şifremi Unuttum]             │  │
│ │                                │  │                                                        │  │
│ │                                │  │  [Giriş Yap] (C04, pembe, full-width, 56px)            │  │
│ │                                │  │                                                        │  │
│ │                                │  │  ── veya şu şekilde devam et ──                        │  │
│ │                                │  │                                                        │  │
│ │                                │  │  [🍎][G][f]   ← Satır 1: Apple, Google, Facebook      │  │
│ │                                │  │  [💬][📷][🎵]  ← Satır 2: WhatsApp, Instagram, TikTok │  │
│ │                                │  │  [🎤]          ← Satır 3: Mikrofon                    │  │
│ │                                │  │  (C08 Social Login, 52×52px, gap:8px)                 │  │
│ │                                │  │                                                        │  │
│ │                                │  │  x:780 y:560                                           │  │
│ │                                │  │  Hesabın yok mu? [Kayıt Ol]                           │  │
│ └────────────────────────────────┘  └────────────────────────────────────────────────────────┘  │
│                                                                                                 │
│ Layout: 72/28 split — Same as Gender Select                                                    │
│ Auth sayfalarında header/footer YOK                                                            │
│ Left side: Sabit manzara + logo + dekoratif text (tüm auth sayfalarında aynı)                 │
│ Right side: Glass panel + form                                                                 │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.16 — REGISTER STEP 1 — PNG #16

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ PNG #15 (Login) ile AYNI layout, sağ paneldeki form farklı:                                   │
│                                                                                                 │
│ Sol: Aynı manzara + logo + dekoratif text                                                      │
│ Sağ: [Kadın ikonu] "Hesap Oluştur"                                                            │
│      "CoreMusic ailesine katıl, müziğin keyfini çıkar"                                        │
│                                                                                                 │
│ x:780 y:160                                                                                    │
│ Kullanıcı Adı                                                                                  │
│ ┌──────────────────────────────────────────────────────────────┐                              │
│ │ E-postanızı yazınız                          (C06, 56px)   │                              │
│ └──────────────────────────────────────────────────────────────┘                              │
│ E-posta                                                                                       │
│ ┌──────────────────────────────────────────────────────────────┐                              │
│ │ E-postanızı yazınız                          (C06, 56px)   │                              │
│ └──────────────────────────────────────────────────────────────┘                              │
│                                                                                                 │
│ [Devam Et] (C04, pembe, full-width, 56px)                                                     │
│                                                                                                 │
│ ── veya şu şekilde devam et ──                                                                │
│ [🍎][G][f]                                                                                   │
│ [💬][📷][🎵]                                                                                 │
│ [🎤]                                                                                          │
│ Hesabın yok mu? [Kayıt Ol]                                                                    │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.17 — REGISTER STEP 2 — PNG #17

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Sol: Aynı manzara + logo + dekoratif text                                                      │
│ Sağ: [Kadın ikonu] "Hesap Oluştur"                                                            │
│                                                                                                 │
│ x:780 y:160                                                                                    │
│ Şifre                                                                                          │
│ ┌──────────────────────────────────────────────────────────────┐                              │
│ │ E-postanızı yazınız                          (C06, 56px)   │                              │
│ └──────────────────────────────────────────────────────────────┘                              │
│ Şifre Tekrar                                                                                  │
│ ┌──────────────────────────────────────────────────────────────┐                              │
│ │ E-postanızı yazınız                          (C06, 56px)   │                              │
│ └──────────────────────────────────────────────────────────────┘                              │
│                                                                                                 │
│ [Devam Et] (C04, pembe, full-width, 56px)                                                     │
│                                                                                                 │
│ ── veya şu şekilde devam et ──                                                                │
│ [🍎][G][f]                                                                                   │
│ [💬][📷][🎵]                                                                                 │
│ [🎤]                                                                                          │
│ Hesabın yok mu? [Kayıt Ol]                                                                    │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

### 4.18 — REGISTER STEP 3 — PNG #18

```
┌─────────────────────────────────────────────────────────────────────────────────────────────────┐
│ Sol: Aynı manzara + logo + dekoratif text                                                      │
│ Sağ: [Kadın ikonu] "Hesap Oluştur"                                                            │
│                                                                                                 │
│ x:780 y:160                                                                                    │
│ Telefon                                                                                         │
│ ┌──────────────────────────────────────────────────────────────┐                              │
│ │ E-postanızı yazınız                          (C06, 56px)   │                              │
│ └──────────────────────────────────────────────────────────────┘                              │
│                                                                                                 │
│ ☐ Kullanım şartlarını ve Gizlilik Politikasını kabul ediyorum.                               │
│                                                                                                 │
│ [Kayıt Ol] (C04, pembe, full-width, 56px)                                                     │
│                                                                                                 │
│ ── veya şu şekilde devam et ──                                                                │
│ [🍎][G][f]                                                                                   │
│ [💬][📷][🎵]                                                                                 │
│ [🎤]                                                                                          │
│ Hesabın yok mu? [Kayıt Ol]                                                                    │
│                                                                                                 │
│ KVKK checkbox zorunlu — seçilmemişse "Kayıt Ol" pasif                                        │
└─────────────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 5. Auth Akış Diyagramı

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│ Select Gender │────→│    Login      │────→│ Register S1  │
│   (PNG #13)   │     │  (PNG #15)   │     │  (PNG #16)   │
│   İLK ADIM    │     │              │     │ Kullanıcı Adı│
│  3 seçenek:   │     │ Email+Şifre  │     │ + E-posta    │
│  Kız/Erkek/   │     │ + Sosyal     │     │              │
│  Diğer        │     │ + Kayıt Ol   │     │ [Devam Et]   │
└──────────────┘     └──────────────┘     └──────┬───────┘
                                                  │
                                                  ↓
                     ┌──────────────┐     ┌──────────────┐
                     │ Register S3  │←────│ Register S2  │
                     │  (PNG #18)   │     │  (PNG #17)   │
                     │ Telefon+KVKK │     │ Şifre+Tekrar │
                     │              │     │              │
                     │ [Kayıt Ol]   │     │ [Devam Et]   │
                     └──────────────┘     └──────────────┘

Tema Etkisi: Select Gender seçimi → data-gender attribute → CSS custom properties
female → #ff4fd8 (pembe)
male → #4f9fff (mavi)
neutral → #a0a0b0 (nötr)
```

---

## 6. Bileşen Kullanım Matrisi

| Bileşen | Home | Welcome | Albums | Album Det | Artists | Playlist | Video | Browse | WiFi | BT | Gender | Login | Reg1 | Reg2 | Reg3 |
|---------|------|---------|--------|-----------|---------|----------|-------|--------|------|-----|--------|-------|------|------|------|
| C01 Nav | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C02 Status | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C03 User | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C04 Primary | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ | ❌ | ❌ | ⚠️ | ✅ | ✅ | ✅ | ✅ |
| C05 Secondary | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C06 Form | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ |
| C07 Gender | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ |
| C08 Social | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ |
| C09 Card | ✅ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C10 Panel | ❌ | ❌ | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C11 Tabs | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C12 Stars | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C13 Track | ❌ | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C14 Modal | ❌ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C15 Toggle | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| C16 Network | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |

---

## 7. Quality Report

| Metrik | Değer |
|--------|-------|
| Version | 3.0.0 |
| Total PNG | 18 (12 home + 6 shared) |
| ASCII Art Views | 18 (tümü piksel düzeyinde) |
| Platforms | 9 (1 mevcut, 8 planlandı) |
| Auth Flow | Select Gender → Login → Register (3 adım) |
| Contradictions | 5 (tümü karar bekliyor) |
| Components | 16 (C01-C16) |
| Layout Patterns | 5 (Standard, Split, Fullscreen, Modal, Auth) |
| ADR Uyumlu | ✅ ADR-001, ADR-044 |
| Zero Hallucination | ✅ Tüm ölçümler PNG'den |

---

*Mockup Index v3.0.0 — CoreMusic UI Design System*
*Authority: Bayram Ali / Vault Steward*
*Last Updated: 2026-08-11*
*Mode: Red Team · Human Mode · Truth Mode*
