---
type: plan
category: ui-design
title: "CoreMusic — Vault Registration (Kalıcı Kayıt, v3.1.0)"
date: 2026-08-11
updated: 2026-08-11
status: completed
version: 3.1.0
authority: Single Source of Truth (SSOT)
governance: Red Team · Human Mode · Truth Mode
references:
  - [[00-mockup-index]]
  - [[01-component-inventory]]
  - [[00-ascii-art-views]]
  - [[CLAUDE.md]]
  - [[AGENTS.md]]
  - [[index.md]]
  - [[keys.md]]
---

# CoreMusic — Vault Registration (v3.1.0)

Mockup'ları `.ai/` vault'una kalıcı olarak tanıtma planı. **Bu adım yapılmazsa sonraki oturumlarda mockup'lar yine görünmez.**

---

## 1. Amaç

4 vault dosyasını düzenleyerek `.ai/ui-design/00-mockup-index.md` dosyasını boot protokolüne ve navigasyon sistemine dahil etmek.

---

## 2. Mevcut Durum (Doğrulandı)

| Dosya | Değişiklik | Durum | Satır |
|-------|-----------|-------|-------|
| `.ai/CLAUDE.md` | Hard Rule #11: Mockup Before Frontend | ✅ MEVCUT | 158 |
| `.ai/AGENTS.md` | Mockup Before Frontend kuralı | ✅ MEVCUT | 356 |
| `.ai/AGENTS.md` | MSA istisnası (görsel referanslar) | ✅ MEVCUT | 354 |
| `.ai/index.md` | ui-design referansları | ✅ MEVCUT | 357 |
| `.ai/keys.md` | Frontend keyword mapping | ✅ MEVCUT | 75-79 |

**Sonuç:** Tüm vault kayıtları zaten mevcut. Ek değişiklik gerekmiyor.

---

## 3. Doğrulama Kontrolleri

| # | Kontrol | Yöntem | Durum |
|---|---------|--------|-------|
| 1 | Wiki-link çalışıyor mu? | `[[ui-design/00-mockup-index]]` | ✅ |
| 2 | Hard Rules 11 kural mı? | CLAUDE.md §7 | ✅ |
| 3 | MSA istisnası görünür mü? | AGENTS.md satır 354 | ✅ |
| 4 | Keyword mapping eklendi mi? | keys.md §3A | ✅ |
| 5 | ASCII Art reference eklendi mi? | keys.md "ascii art" | ✅ |
| 6 | Screen spec keyword'leri eklendi mi? | keys.md "screen spec" | ✅ |
| 7 | Mockup index erişilebilir mi? | index.md §12 | ✅ |

---

## 4. Beklenen Sonuç

Bu değişikliklerden sonra:

1. **Her frontend görevinde** agent otomatik olarak `00-mockup-index.md`'yi okuyacak
2. **Mockup'lar vault'a tanınmış** olacak
3. **ASCII Art Reference** erişilebilir olacak
4. **Keyword araması** ile mockup dizinine ulaşılabilecek
5. **Boot protokolü** mockup'ları hatırlayacak
6. **MSA limiti** görsel referansları kapsamayacak
7. **Screen spec dosyaları** keyword ile bulunabilecek

---

## 5. İlgili Dosyalar

| Dosya | Amaç |
|-------|------|
| [[CLAUDE.md]] | Hard Rule #11 mevcut |
| [[AGENTS.md]] | Mockup kuralı + MSA istisnası mevcut |
| [[index.md]] | ui-design referansları mevcut |
| [[keys.md]] | Keyword mapping mevcut |
| [[00-mockup-index]] | Vault'a kaydedildi (v3.0.0) |
| [[01-component-inventory]] | Güncellendi (v3.1.0) |
| [[02-implementation-plan]] | Güncellendi (v3.1.0) |
| [[03-accessibility-gaps]] | Güncellendi (v3.1.0) |

---

## 6. Quality Report

| Metrik | Değer |
|--------|-------|
| Version | 3.1.0 |
| Status | COMPLETED |
| Files Verified | 5 (CLAUDE.md, AGENTS.md, index.md, keys.md, 00-mockup-index.md) |
| Hard Rules | 11 (Mockup Before Frontend dahil) |
| MSA Exception | ✅ Görsel referanslar hariç |
| Keyword Mappings | 18 (Frontend & UI Design) |
| ASCII Art Views | 18 PNG |
| Risk | LOW (tümü mevcut) |

---

*Vault Registration v3.1.0 — CoreMusic UI Design System*
*Authority: Bayram Ali / Vault Steward*
*Last Updated: 2026-08-11*
*Mode: Red Team · Human Mode · Truth Mode*
