---
title: CoreMusic — Flow Index
date: 2026-08-11
version: 2.0.0
platform: home-1024
---

# CoreMusic — Kullanıcı Akışları

## Auth Flow (5 dosya)

| # | Dosya | Akış |
|---|-------|------|
| 1 | auth/01-login.md | Giriş yapma |
| 2 | auth/02-register.md | Kayıt olma (3 adım) |
| 3 | auth/03-forgot-password.md | Şifre sıfırlama |
| 4 | auth/04-select-gender.md | Cinsiyet seçimi (ilk adım) |
| 5 | auth/05-logout.md | Çıkış yapma |

## Music Flow (5 dosya)

| # | Dosya | Akış |
|---|-------|------|
| 1 | music/01-playback.md | Şarkı çalma |
| 2 | music/02-playlist-queue.md | Çalma listesi yönetimi |
| 3 | music/03-album-browse.md | Albüm tarama |
| 4 | music/04-artist-browse.md | Sanatçı tarama |
| 5 | music/05-search.md | Arama |

## Settings Flow (4 dosya)

| # | Dosya | Akış |
|---|-------|------|
| 1 | settings/01-wifi-connect.md | WiFi bağlama |
| 2 | settings/02-bluetooth-connect.md | Bluetooth eşleştirme |
| 3 | settings/03-equalizer.md | EQ ayarlama |
| 4 | settings/04-general.md | Genel ayarlar |

## Navigation Flow (3 dosya)

| # | Dosya | Akış |
|---|-------|------|
| 1 | navigation/01-spa-routing.md | SPA yönlendirme |
| 2 | navigation/02-header-nav.md | Header navigasyonu |
| 3 | navigation/03-footer-player.md | Footer player |
