---
title: CoreMusic — Auth Flow: Select Gender (Detaylı)
date: 2026-08-11
version: 2.0.0
platform: home-1024 (Linux Embedded RPi5, 1024×600)
author: Senior Frontend Architect (50+ yıl deneyim)
references:
  - [[screens/A-auth/gender-select]]
  - [[screens/00-ascii-art-views]] §13
  - [[01-component-inventory]] C07, C04
  - [[ADR-044-dynamic-user-theme-engine]]
---

# Auth Flow: Select Gender — Detaylı Akış Analizi

## Platform: Linux Embedded / Raspberry Pi 5 / 1024×600px

---

## 1. GENEL AKIŞ

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    SELECT GENDER AKIŞI                                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                  │
│  │ İlk Giriş    │ →  │ 3 Gender     │ →  │ Tema         │                  │
│  │ (cookie yok) │    │ Seçimi       │    │ Değişimi     │                  │
│  └──────────────┘    └──────────────┘    └──────────────┘                  │
│                                                     │                       │
│                                              ┌──────┴──────┐               │
│                                              │              │               │
│                                         ┌────▼────┐  ┌─────▼─────┐        │
│                                         │ Kız     │  │ Erkek     │        │
│                                         │ (pink)  │  │ (blue)    │        │
│                                         └────┬────┘  └─────┬─────┘        │
│                                              │              │               │
│                                              │        ┌─────▼─────┐        │
│                                              │        │ Diğer     │        │
│                                              │        │ (neutral) │        │
│                                              │        └─────┬─────┘        │
│                                              │              │               │
│                                              └──────┬───────┘               │
│                                                     │                       │
│                                              ┌──────▼──────┐               │
│                                              │ "Devam Et"  │               │
│                                              │ tıklanır    │               │
│                                              └──────┬──────┘               │
│                                                     │                       │
│                                              ┌──────▼──────┐               │
│                                              │    Login    │               │
│                                              │   Sayfası   │               │
│                                              └─────────────┘               │
│                                                                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. SAYFA YAPISI (PNG Layout)

### 2.1 — Sol Alan (~800px, %78)

| Özellik | Değer |
|---------|-------|
| Arka plan | Tam kaplama fotoğraf (pembe tonları, sunset, fields, fantasy) |
| Logo | Sol üst, ~60×40px |
| Başlık | "Seni Tanıyalım" (24px, Bickham Script Two) |
| Alt metin | "Deneyimini sana özel hale getirmek için bir seçim yapman yeterli." (12px, Arima, muted) |
| Gradient | Sol alttan sağ üste pembe gradient overlay |

### 2.2 — Sağ Panel (~224px, %22)

| Özellik | Değer |
|---------|-------|
| Background | `rgba(255,255,255,0.05)` |
| Backdrop | `blur(20px) saturate(180%)` |
| Border-radius | 0 (sol kenar yuvarlak değil) |
| Padding | 20px |

#### 女神 İkonu
| Özellik | Değer |
|---------|-------|
| Boyut | ~60×60px |
| Konum | Sağ panel üst, orta hizalı |
| Stil | Beyaz çizim, ince hat |
| CSS | `.auth-panel__deity-icon` |

#### Başlık
| Özellik | Değer | Token |
|---------|-------|-------|
| Metin | "Seni Tanıyalım" | — |
| Font | Bickham Script Two | `--font-logo` |
| Boyut | 18px | `--text-lg` |
| Renk | Beyaz | `--color-white` |
| Hizalama | Ortada |

#### Alt Başlık
| Özellik | Değer | Token |
|---------|-------|-------|
| Metin | "Müzik deneyimini sana özel getirelim" | — |
| Font | Arima | `--font-body` |
| Boyut | 11px | `--text-xs` |
| Renk | `rgba(255,255,255,0.6)` | `--color-text-muted` |
| Hizalama | Ortada |

---

## 3. GENDER BUTONLARI (C07) DETAY

### 3.1 — Buton Yapısı

```
┌─────────────────────────────────────────────────────┐
│  [👩 ikon 30×30px]  Kız                              │
│                     Temizlik, saf duygular           │
│                     Pembemsi renk tonları            │
│                                                     │
│  Boyut: ~200×80px (tam genişlik, padding ile)       │
│  Border-radius: 12px                                 │
│  Border: 1px solid rgba(255,255,255,0.15) (default) │
│  Background: rgba(255,255,255,0.05) (default)       │
│  Padding: 12px 16px                                  │
│  Gap (ikon ile metin arası): 12px                   │
└─────────────────────────────────────────────────────┘
```

### 3.2 — 3 Varyant

| Özellik | Kız (female) | Erkek (male) | Diğer (neutral) |
|---------|-------------|-------------|-----------------|
| İkon | 👩 | 👨 | 🤷 |
| Başlık | Kız | Erkek | Cinsiyetimi belirtmek istemiyorum |
| Alt metin | Temizlik, saf duygular · Pembemsi renk tonları | Güçlü, klasik tonlar · Mavimsi renk tonları | Nötr renk tonları |
| Tema | female | male | neutral |
| Accent | #ff4fd8 (pembe) | #4f9fff (mavi) | #a0a0b0 (gri) |
| Seçili bg | rgba(255,79,216,0.2) | rgba(79,159,255,0.2) | rgba(160,160,176,0.2) |
| Seçili border | 2px solid #ff4fd8 | 2px solid #4f9fff | 2px solid #a0a0b0 |
| İkon rengi | #ff4fd8 | #4f9fff | #a0a0b0 |

### 3.3 — Seçili Durum (Selected State)

```
┌═══════════════════════════════════════════════════════┐
│  [👩 ikon 30×30px]  Kız  ← PEMBE VURGU               │
│  ║         Temizlik, saf duygular           ║         │
│  ║         Pembemsi renk tonları            ║         │
│  ═══════════════════════════════════════════════════   │
│  background: rgba(255,79,216,0.2)                     │
│  border: 2px solid var(--theme-primary)               │
│  box-shadow: 0 0 20px rgba(255,79,216,0.3)           │
└═══════════════════════════════════════════════════════┘
```

### 3.4 — Gap (Butonlar Arası)

| Özellik | Değer |
|---------|-------|
| Butonlar arası | 8px |
| Toplam yükseklik (3 buton) | 3×80 + 2×8 = 256px |
| Mevcut yükseklik | ~320px (başlık + butonlar + buton) |

---

## 4. "DEVAM ET" BUTONU

| Özellik | Değer | Token |
|---------|-------|-------|
| Metin | "Devam Et" | — |
| Yükseklik | 56px | `--btn-h` |
| Genişlik | Tam genişlik (~180px) | — |
| Background (default) | `rgba(255,255,255,0.1)` | `--glass-bg` |
| Background (aktif) | `var(--theme-primary)` | #ff4fd8 |
| Text | #ffffff | — |
| Font | 14px, 600 | `--text-base`, `--font-semibold` |
| Border-radius | 8px | `--radius-md` |
| Margin-top | 12px | `--space-3` |
| Transition | 250ms ease | `--transition-base` |

### Durumlar

| Durum | Değişiklik |
|-------|-----------|
| Başlangıçta | `bg: rgba(255,255,255,0.1)`, `opacity: 0.5` (devre dışı) |
| Seçim yapıldığında | `bg: var(--theme-primary)`, `opacity: 1` (aktif) |
| Hover | (TOKUNMATİK CİHAZDA YOK) |
| Focus-visible | `outline: 2px solid var(--theme-primary)` |
| Click | Scale: 0.98 (100ms) |

---

## 5. ALT METİNLER

### 5.1 — Alıntı

| Özellik | Değer |
|---------|-------|
| Metin | "Hayatın ritmini sende gizli, müziğinle parti!" |
| Font | Bickham Script Two, italik |
| Boyut | 14px |
| Renk | `var(--theme-primary)` (pembe) |
| Hizalama | Ortada |
| Margin-top | 12px |

### 5.2 — Gizlilik Politikası

| Özellik | Değer |
|---------|-------|
| Metin | "Devam ederek ·Gizlilik Politikamı· kabul etmiş olursunuz." |
| Font | Arima, 9px |
| Renk | `rgba(255,255,255,0.4)` |
| Hizalama | Ortada |
| Link | "Gizlilik Politikamı" — underline, tıklanabilir |
| Link rengi | `var(--theme-primary)` |

---

## 6. DAVRANIŞ DETAYLARI

### 6.1 — Sayfa Yükleme

```
Sayfa yüklenir
  → Sağ panel glass efekti ile fade-in (300ms)
  → 3 buton sırayla görünür (stagger animation: 100ms aralıkla)
  → Hiçbiri seçili değil
  → "Devam Et" butonu devre dışı (gri, opacity:0.5)
  → Sol alan arka plan fotoğrafı yüklenir
  → Logo ve başlık sol üstte görünür
```

### 6.2 — Buton Seçimi

```
Kullanıcı bir butona tıklar
  → Seçili buton:
    → border: 2px solid var(--theme-primary)
    → background: rgba(theme-primary, 0.2)
    → box-shadow: 0 0 20px rgba(theme-primary, 0.3)
    → scale: 1.02 (200ms ease)
  → Diğer butonlar:
    → Default state'e döner (border: 1px, bg: 0.05)
    → scale: 1.0 (200ms ease)
  → "Devam Et" butonu:
    → opacity: 0.5 → 1.0 (200ms)
    → background: rgba(255,255,255,0.1) → var(--theme-primary)
    → click event aktif olur
  → Tema rengi anında değişir:
    → document.documentElement.setAttribute('data-gender', gender)
    → CSS custom properties güncellenir
    → Tüm sayfadaki accent renkleri değişir
```

### 6.3 — "Devam Et" Tıklama

```
Kullanıcı "Devam Et"'e tıklar
  → Cookie ayarla: theme_gender=female|male|neutral (365 gün)
  → LocalStorage'a kaydet: theme_gender (fallback)
  → ThemeManager.setTheme(gender) çağır
  → Login sayfasına yönlendirme (/auth/login)
  → Geçiş animasyonu: sağ panel sola kayar (300ms)
```

### 6.4 — Geri Dönüş

```
Kullanıcı geri ok'a tıklar (eğer varsa)
  → Landing page'e yönlendirme
  → Cookie silinir (eğer bu ilk girişse)
```

---

## 7. TEMA SİSTEMİ ENTEGRASYONU

### 7.1 — CSS Custom Properties

```css
:root {
  --theme-primary: #ff4fd8;  /* varsayılan */
}

[data-gender="female"] {
  --theme-primary: #ff4fd8;  /* pembe */
  --color-bg: #1a0a14;
  --accent-glow: rgba(255,79,216,0.3);
}

[data-gender="male"] {
  --theme-primary: #4f9fff;  /* mavi */
  --color-bg: #0a1420;
  --accent-glow: rgba(79,159,255,0.3);
}

[data-gender="neutral"] {
  --theme-primary: #a0a0b0;  /* gri */
  --color-bg: #121218;
  --accent-glow: rgba(160,160,176,0.3);
}
```

### 7.2 — JS ThemeManager

```javascript
class ThemeManager {
  static setTheme(gender) {
    document.documentElement.setAttribute('data-gender', gender);
    document.body.setAttribute('data-gender', gender);
    document.cookie = `theme_gender=${gender};path=/;max-age=31536000`;
  }

  static getTheme() {
    const match = document.cookie.match(/theme_gender=([^;]+)/);
    return match ? match[1] : 'neutral';
  }

  static init() {
    const gender = this.getTheme();
    this.setTheme(gender);
  }
}
```

### 7.3 — Etkilenen Bileşenler

| Bileşen | Tema Değişikliği |
|---------|-----------------|
| Accent renk | `--theme-primary` |
| Buton renkleri | Primary/secondary |
| Tab aktif rengi | Genre tabs |
| Toggle rengi | WiFi/BT toggle |
| İkon renkleri | Header status |
| Arka plan gradient | Sol alan |
| Glow efekti | Seçili buton |

---

## 8. ERİŞİLEBİLİRLİK (WCAG 2.2 AA)

| Kriter | Durum | Not |
|--------|-------|-----|
| Touch target (buton) | ✅ | ~200×80px |
| Touch target (devam et) | ✅ | 56px |
| Focus indicator | ✅ | `outline: 2px solid var(--theme-primary)` |
| Keyboard nav | ✅ | Tab ile seçim, Enter ile devam |
| ARIA | ⚠️ eksik | `role="radiogroup"` ekle |
| Renk kontrastı | ✅ | Beyaz text, pembe/mavi/nötr |
| Screen reader | ⚠️ eksik | `aria-label` ekle |
| Animasyon | ✅ | `prefers-reduced-motion` desteği |

---

## 9. ANİMASYON DETAYLARI

| Durum | Animasyon | Süre | Easing |
|-------|----------|------|--------|
| Sayfa yükleme | Fade-in | 300ms | ease |
| Buton stagger | Sıralı görünüm | 100ms aralıkla | ease |
| Buton seçimi | Scale 1.02 + glow | 200ms | ease |
| Buton seçim kaldırma | Scale 1.0 + glow yok | 200ms | ease |
| Devam Et aktifleşme | Opacity + bg change | 200ms | ease |
| Sayfa geçişi | Sağ panel slide-left | 300ms | ease-in-out |

---

## 10. PERFORMANS NOTLARI

| Metrik | Hedef |
|--------|-------|
| FCP | <1.5s |
| LCP | <2.5s (arka plan fotoğrafı) |
| CLS | <0.1 |
| TTI | <3s |
| Font loading | FOUT (Bickham Script Two) |
| Image | Lazy loading + `loading="lazy"` |

---

## 11. İLGİLİ DOSYALAR

| Dosya | Amaç |
|-------|------|
| [[screens/A-auth/gender-select]] | Gender screen spec |
| [[screens/00-ascii-art-views]] §13 | ASCII art view |
| [[screens/_layout-patterns/05-auth-screen]] | Auth layout pattern |
| [[01-component-inventory]] C07, C04 | Bileşen detayları |
| [[ADR-044-dynamic-user-theme-engine]] | Tema motoru |
| [[flow/auth/01-login]] | Login akışı (sonraki adım) |

---

## 12. Quality Report

| Metrik | Değer |
|--------|-------|
| Version | 2.0.0 |
| Platform | home-1024 |
| Layout Pattern | 5: Auth Screen (78/22) |
| Components | C07 (3 varyant), C04 |
| Gender Options | 3 (female, male, neutral) |
| Theme Changes | 12+ CSS custom property |
| Animations | 6 (fade, stagger, scale, glow, slide) |
| WCAG Gaps | 2 (ARIA, screen reader) |
| Cookie | theme_gender (365 gün) |

---

*Select Gender Flow v2.0.0 — CoreMusic UI Design System*
*Authority: Bayram Ali / Vault Steward*
*Last Updated: 2026-08-11*
*Mode: Red Team · Human Mode · Truth Mode*
