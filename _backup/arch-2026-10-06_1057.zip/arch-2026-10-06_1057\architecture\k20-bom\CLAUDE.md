---
title: "CoreMusic — K20 BOM CLAUDE.md"
type: layer-guide
folder: "architecture/k20-bom"
category: vault
date: 2026-09-20
status: active
version: 1.0.2
authority: reference
---

# K20 BOM — CLAUDE.md

## 1. BOM Hedefleri

| Kategori | Hedef |
|----------|-------|
| Toplam bileşen | ~1000 (hedef; gerçekleşen özet: 500 — index.md "Toplam Bileşen Özeti") |
| Toplam maliyet | <$430 |
| Tedarikçi | Mouser/Digikey |

## 2. Maliyet Dağılımı

| Kategori | Maliyet |
|----------|---------|
| Amplifikatör | $56 |
| DAC + USB | $20 |
| Güç kaynağı | $9 |
| Pasif | $180 |
| PCB | $50 |

---

*K20 CLAUDE.md v1.0.1 — CoreMusic*
*Authority: Bayram Ali / Vault Steward*
*Last Updated: 2026-09-29*
